# Blueprint: пакеты для статей концептуально-технического атласа

Статус: рабочий blueprint для будущих target-group plans статей концептуально-технического атласа.

Назначение: задать форму **плана плана** для больших самостоятельных статей атласа. Этот документ не описывает конкретную статью SPDD, PWG, Gas Town, BMAD или другой концепции; он задаёт общую очередь проходов, требования к источникам, визуальному слою, companion-файлам и финальной проверке, чтобы результат пакета требовал не механической доводки, а в основном смыслового человеческого обсуждения.

## 1. Что такое статья атласа

Статья атласа — это не фрагмент общей теории и не техническое приложение. Это большая самостоятельная concept-first статья по одной концепции, методологии, механизму или инструментальной форме.

Читатель должен иметь возможность открыть статью атласа — например, по SPDD, PWG / Beads, Gas Town, BMAD, GSD, TDAD, Spec Kit, Kiro, Sandvault или HumanLayer harness — и получить связное понимание концепции без обязательной предварительной сборки материала из разных глав теории.

Статья атласа должна:

- отвечать на явный reader question;
- объяснять концепцию, проблему, механизм, границы и типичные ошибки;
- раскрывать источниковую фактуру из досье и первоисточников, а не заменять её общими тезисами;
- включать релевантные команды, файлы, UI, screenshots, diagrams, caveats, edge cases и ограничения;
- контролируемо повторять тезисы теории, когда это нужно для самостоятельного понимания;
- давать смысловые связи с общей теорией, но не строить всю теорию заново;
- использовать готовые локальные изображения и реальные внешние image candidates как нормальную часть статьи.

## 2. Ключевые запреты

В планах статей атласа нельзя:

- задавать внутренний потолок объёма текста;
- сокращать статью ради компактности;
- закрывать недостаток фактуры гладкой общей прозой;
- оставлять косвенные формулы вроде «в одном эпизоде фактически сделали X», если из источника можно описать, что именно было сделано;
- подменять реальные изображения текстовыми схемами;
- игнорировать локальные ассеты только потому, что тяжёлые файлы не загружены в текущий package;
- превращать внешние реальные картинки в синтетические схемы;
- добавлять собственные схемы ради визуального разнообразия;
- писать служебные captions вроде «восстановленная source-иллюстрация», «локальный файл», «кандидат для вставки»;
- превращать статью атласа в механический technical appendix;
- превращать статью атласа в полную альтернативную теорию;
- превращать article map в мини-атлас.

## 3. Объём: никаких внутренних лимитов

Для atlas article package действует прямое правило:

> Не устанавливай внутренний потолок объёма статьи. Объём определяется полнотой раскрытия концепции, значимостью источниковой фактуры, техническими деталями, изображениями, ограничениями и edge cases. Сжимай только повторы, служебный шум, механические перечисления и фактуру, которая не работает на reader question.

Если после source-depth проходов статья остаётся конспективной, следующий проход должен добирать материал, а не шлифовать краткий обзор.

## 4. Разрешение на внешние источники

Atlas article package может обращаться к внешним источникам, если они нужны для:

- проверки и насыщения статьи;
- раскрытия первоисточников, на которые указывает досье;
- уточнения команд, UI, файлов, статусов, ограничений и версий;
- поиска реальных изображений, screenshots, diagrams, architecture sketches, README images, UI screenshots или source diagrams;
- восстановления внешних image candidates для будущего asset-pass.

Предпочтение всегда у первоисточников: официальная документация, репозиторий, README, changelog, blog автора/проекта, статья разработчика, страница продукта, issue/PR/discussion, если именно они являются источником факта.

Внешние источники нельзя использовать как случайное расширение темы. Если факт или изображение взяты извне, source usage должен фиксировать источник, место использования и причину добавления. Если источник недоступен, это фиксируется как gap; утверждение не выдумывается.

## 5. Визуальный слой для статей атласа

В отличие от обычных A/B/C-фрагментов, статья атласа может и должна быть визуально насыщенной, если изображения помогают понять концепцию, UI, workflow, архитектуру, артефакты или source-specific механику.

### 5.1. Локальные ассеты

Если релевантный локальный asset уже существует в репозитории, его надо вставить в статью как настоящий image figure, даже если тяжёлый файл не включён в текущий package context.

Форма:

```html
<figure id="fig-..." class="image-asset">
  <img src="content/assets/theory-images/..." alt="..." />
  <figcaption>Публичная подпись: что показывает изображение и почему оно важно для понимания концепции.</figcaption>
</figure>
```

Подпись не должна рассказывать историю восстановления файла или показывать локальный путь как служебную заметку. Путь живёт в `img src` и image plan, а не в prose-caption.

### 5.2. Внешние реальные изображения

Если в источнике есть реальное изображение, screenshot, source diagram, график или UI-снимок, но оно ещё не скачано и не локализовано, его нужно:

1. поставить в нужное место статьи как placeholder figure;
2. добавить в нижний временный раздел `Внешние изображения для asset-pass`;
3. записать в image plan / external image queue.

Форма inline-placeholder:

```html
<figure id="fig-..." data-asset-status="external-real-candidate">
  <figcaption>Здесь нужна реальная диаграмма/скриншот из источника: она показывает ...</figcaption>
</figure>
```

Форма нижнего раздела:

```markdown
## Внешние изображения для asset-pass

### fig-...
- Источник: ...
- Что взять: конкретная диаграмма / screenshot / section / image
- Зачем нужна: ...
- Предлагаемый локальный путь: content/assets/atlas-images/...
- Где стоит в тексте: после раздела ...
- Статус: external-real-candidate; download/rights/quality check required
```

Пакет не скачивает такие изображения, если это не является отдельной задачей. Он должен подготовить точную очередь для будущего asset-pass.



### 5.2.1. Dossier image candidates

Before searching broadly, the article-writing package must inspect the main dossier's image-candidate section: headings such as `## Кандидаты на иллюстрации`, `Кандидаты на изображения`, `image candidates`, or equivalent lists. These dossier candidates are first-class inputs, not optional inspiration.

For every dossier image candidate, the article must record a disposition in `<article_id>_image_plan.md`:

- `inserted_inline_external_placeholder` — placed in the article as `<figure data-asset-status="external-real-candidate">` and mirrored in the bottom asset-pass section and external image queue;
- `external_queue_only` — relevant but not placed inline yet;
- `deferred` — potentially useful, but depends on future section/asset decision;
- `rejected` — not useful for this article, with reason;
- `superseded_by_local_asset` — replaced by an existing local asset;
- `not_found_in_source` — candidate was listed but could not be verified in the source during the pass.

If the image supports a concrete article section, prefer inline placement plus a bottom `Внешние изображения для asset-pass` entry. Do not hide useful dossier candidates only in companion files.

### 5.3. Собственные схемы

Синтетические фигуры допустимы редко. Они нужны только там, где действительно проясняют нетривиальную связь, процесс, boundary, lifecycle-переход или сравнение, которое плохо держится одной прозой.

Синтетическая схема не должна:

- заменять готовый local asset;
- заменять внешнюю реальную картинку, которую надо взять из источника;
- повторять соседний абзац в виде банальной таблицы;
- закрывать пункт «добавить figure» ради количества.

## 6. Выходы пакета

Для каждой статьи атласа план должен задавать как минимум такие выходы:

```text
work/atlas/articles/<article_id>.md
work/atlas/articles/<article_id>_source_usage.md
work/atlas/articles/<article_id>_source_transfer_ledger.md
work/atlas/articles/<article_id>_image_plan.md
work/atlas/articles/<article_id>_external_image_queue.md
work/atlas/articles/<article_id>_open_questions.md
work/atlas/articles/<article_id>_theory_links.md
work/atlas/articles/<article_id>_degradation_and_duplication_audit.md
work/atlas/articles/<article_id>_readiness_report.md
```

Если в репозитории позже будет принято другое расположение статей атласа, пути можно адаптировать, но роли выходов должны сохраниться.

`source_transfer_ledger` особенно важен: он показывает, что пакет действительно раскрыл досье и первоисточники, а не написал красивое резюме верхнего слоя.

## 7. Базовая очередь: 25 рабочих проходов + финальная проверка

Для большой статьи атласа базовая очередь должна содержать **25 рабочих проходов плюс отдельную финальную проверку**.

```text
P01 — первичный концептуальный черновик статьи
P02 — article contract: reader question, boundaries, article tier, relation to theory
P03 — dossier inventory: что есть в досье и первоисточниках

P04 — source-depth pass 1: ключевая фактура
P05 — source-depth pass 2: техническая механика, команды, артефакты
P06 — source-depth pass 3: ограничения, failures, caveats, edge cases
P07 — source-depth pass 4: добор пропущенных источниковых деталей
P08 — source-depth pass 5: анти-конспектная проверка

P09 — свободный добор материала 1
P10 — свободный добор материала 2

P11 — visual asset pass 1: локальные готовые изображения
P12 — visual asset pass 2: внешние реальные изображения-кандидаты
P13 — visual asset pass 3: редкие нетривиальные собственные схемы

P14 — concept reinforcement 1: самостоятельное объяснение концепции
P15 — concept reinforcement 2: механизм, границы, типичные ошибки
P16 — concept reinforcement 3: связь с общей теорией без превращения в теорию

P17 — общий редакторский проход 1
P18 — общий редакторский проход 2
P19 — общий редакторский проход 3

P20 — public/article structure pass
P21 — companion sync / source ledger / image queue pass

P22 — языковой проход 1
P23 — языковой проход 2
P24 — стилевой проход 1
P25 — стилевой проход 2

Final — финальная проверка, упаковка, readiness status
```

Не сокращай очередь по умолчанию. Сокращение допустимо только после отдельного решения для маленькой статьи или source note / case note.

## 8. Свободные проходы добора

P09 и P10 — свободные доборные проходы. Они свободны по выбору зоны улучшения, но не свободны в смысле бесконтрольного переписывания.

Каждый такой проход должен сам найти, где текущая статья всё ещё недостаточна, и добавить материал в текст и companion-файлы.

Минимальная запись результата прохода:

```text
Что я счёл главным недобором:
Что добавил:
Откуда взял материал:
Что осталось долгом:
```

P09 обычно добирает фактуру: команды, артефакты, шаги, статусы, конкретные эпизоды, технические детали, мало раскрытые источники.

P10 обычно добирает связность концепции: объяснение механизма, границы, сравнения, ограничения, типичные ошибки, переходы между деталями и общей концепцией.

Если модель видит другой более важный недобор, она может выбрать его, но должна объяснить выбор.

## 9. Общие редакторские проходы

После source-depth, свободного добора, визуального слоя и concept reinforcement идут три общих редакторских прохода. Они сохраняют общность и повторяют формулу:

> Оцени, насколько статья выполняет поставленную задачу. Сначала сформулируй проблемы, затем исправь их.

Эти проходы не получают заранее специальной темы. Первый обычно ловит крупные нарушения функции статьи, второй перечитывает результат после правки, третий проверяет глубокие перекосы: статья стала второй теорией, справочником, пересказом досье, набором картинок или недоразвёрнутым конспектом.

## 10. Финальная проверка

Final verification должен проверить:

- основной article file создан и не является конспектом;
- нет внутренних лимитов объёма или следов искусственного сокращения;
- source usage и source transfer ledger заполнены;
- внешние факты имеют provenance;
- локальные релевантные images вставлены как `<img>`;
- external real image candidates стоят в тексте как placeholders и вынесены в нижний раздел / external image queue;
- synthetic figures редки и проходят usefulness/nontriviality gate;
- captions публичные, без служебного мета-текста;
- controlled repetition с теорией оправдано;
- article не стал копией всей теории;
- article не стал складом технических деталей без концептуальной связности;
- companion-файлы синхронизированы;
- readiness status зафиксирован.

## 11. Зависимость от C5

Для разработки **общего blueprint** и конкретных планов статей C5-фрагмент полезен, но не является жёсткой зависимостью.

Если `C5_theory_to_technical_atlas.md` уже написан, его нужно читать как один из входов: он должен дать article map, semantic back-links, tiers и границы concept atlas.

Если C5 ещё не написан, план статьи можно создавать на основе:

- ADR-0011 concept-first atlas decision;
- этого blueprint;
- соответствующего досье и первоисточников;
- текущих A/B/C-фрагментов;
- asset catalog и source maps.

В таком случае план должен записать `C5 sync pending`: после появления C5 article map нужно сверить tier, boundary, reader question, theory links и asset/readiness decisions.

## 12. Связанный план мануфактуры target-group plans

Для создания самих target-group plans статей атласа действует отдельный документ:

```text
work/theory-writing/ATLAS_ARTICLE_TARGET_PLAN_MANUFACTORY_PLAN.md
```

Он описывает meta-package, который запускается на машине с развёрнутым репозиторием, не требует входных архивов от пользователя, берёт known dossier-backed article set из файловой системы, по одной статье создаёт target-group plan, затем улучшает этот plan через свободный редакторский repair, усиление основной мысли/границ, integrated guardrail repair и readiness stamp. Этот meta-package не пишет статьи атласа и не собирает article executor packages; он готовит планы для будущей сборки таких пакетов.


### Self-contained package requirement

Article-writing packages produced from atlas article target-group plans should be self-contained. The target-group plan must list exact read-only input paths to bundle with the package: primary dossier, supporting dossier passes, relevant theory fragments, asset catalog files, local asset paths/directories needed for placement decisions, protocols, style rules and any optional sync inputs. Do not rely on vague placeholders such as “relevant files” or on unstated repository context. If an input cannot be named yet, record it as a readiness debt.
