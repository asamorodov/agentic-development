#!/usr/bin/env python3
from __future__ import annotations
import base64, gzip, json, sys, shutil
from pathlib import Path

BOX = Path('z3k9p.dat')
STATE = Path('.q8v4m_state.json')

def _decode_blob(text: str):
    raw = gzip.decompress(base64.b64decode(text.encode('ascii')))
    return json.loads(raw.decode('utf-8'))

def _load_box():
    return _decode_blob(BOX.read_text(encoding='ascii'))

def _load_state(box):
    if STATE.exists():
        return json.loads(STATE.read_text(encoding='utf-8'))
    return {'current': box['entry'], 'active': True}

def _save_state(state):
    STATE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')

def _write(path, content):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding='utf-8')

def _missing(paths):
    return [p for p in paths if not Path(p).exists()]

def _pack_interrupted():
    Path('INTERRUPTED.md').write_text('Работа прервана до нормального завершения. Архив содержит доступное состояние файловой среды.\n', encoding='utf-8')
    if not Path('RESUME.md').exists():
        Path('RESUME.md').write_text('Для продолжения распакуйте архив и выполните текущую инструкцию либо запустите Python-скрипт, если требуемые файлы текущего шага уже записаны.\n', encoding='utf-8')
    base = shutil.make_archive('interrupted_state', 'zip', Path.cwd())
    print(f'Собран аварийный архив: {base}')

def main():
    if len(sys.argv) > 1 and sys.argv[1] == 'emergency':
        _pack_interrupted(); return
    box = _load_box(); state = _load_state(box)
    if not state.get('active', True):
        print('Текущий материал уже был выдан. Выполни созданный рабочий лист; если работа прервана, используй emergency-команду.'); return
    item = _decode_blob(box['records'][state['current']])
    miss = _missing(item.get('need', []))
    if miss:
        print('Не найдены требуемые файлы предыдущего действия:')
        for m in miss: print('-', m)
        print('Сначала запиши эти файлы, затем снова запусти Python-скрипт.'); return
    for p,c in item.get('emit', {}).items():
        _write(p, c)
    nxt = item.get('next')
    state['current'] = nxt if nxt else state['current']; state['active'] = bool(nxt); _save_state(state)
    if item.get('show'): print(item['show'])

if __name__ == '__main__': main()
