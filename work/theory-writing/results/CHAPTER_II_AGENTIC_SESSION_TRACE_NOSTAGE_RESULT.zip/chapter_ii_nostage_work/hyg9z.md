# Final — сборка результата

Выполни финальный лист только после завершения последнего прохода. Не переписывай главу заново и не имитируй отсутствующие проходы.

## Инструкция Final

Собрать итоговые файлы, `MANIFEST`, `VERIFY`, `RESUME` и краткую оценку готовности. Записать инструкции для обновления `work/discourse.md` и `WORKING_DOCUMENTS_MAP.md`. Пакет не должен менять Skeleton, карты маршрутизации или общий blueprint.

## 7. Критерии готовности

Глава готова, если читатель после неё может сказать:

- агентская сессия важна, потому что в ней видно исполнение, наблюдение, ошибку и вмешательство;
- сессия не является долговечной памятью изменения;
- трасса помогает понять прошлое, но не гарантирует безопасное продолжение;
- наблюдение помогает управлять, но не всегда является свидетельством для принятия;
- после обрыва, сжатия или передачи должны выжить открытые вопросы, запреты, свидетельства, следующий шаг и границы ответственности;
- следующая глава нужна, потому что намерение, контракт и решение требуют собственных носителей.

Глава не готова, если она:

- пересказывает истории по очереди;
- пишет обзор инструментов трассировки;
- превращается в главу про PWG, рантайм или свидетельства;
- учит вести агентскую сессию как практическое руководство;
- теряет различение наблюдение / свидетельство;
- звучит как протокол вместо теоретической главы.

## 8. Заметки для сборщика пакета

Этот план имеет профиль `D2`, поэтому пакет должен включить модуль внешнего поиска. Если внешний поиск невозможен, пакет не должен имитировать его. В таком случае нужно создать `external_discovery_log` со статусом `blocked_without_web_or_external_sources` и явно отметить содержательный риск.

После обновления протокола пакет можно собирать со стадиями или без стадий. Стадийность является внешним параметром сборки и не меняет содержание этого плана.

## Ожидаемые итоговые файлы

- `work/theory-writing/chapters/II_agentic_session_trace.md`
- `work/theory-writing/chapters/II_agentic_session_trace_source_register.md`
- `work/theory-writing/chapters/II_agentic_session_trace_fragment_usage.md`
- `work/theory-writing/chapters/II_agentic_session_trace_atlas_usage.md`
- `work/theory-writing/chapters/II_agentic_session_trace_dossier_gap_notes.md`
- `work/theory-writing/chapters/II_agentic_session_trace_external_discovery_log.md`
- `work/theory-writing/chapters/II_agentic_session_trace_story_anchors.md`
- `work/theory-writing/chapters/II_agentic_session_trace_figure_candidates.md`
- `work/theory-writing/chapters/II_agentic_session_trace_open_questions.md`
- `work/theory-writing/chapters/II_agentic_session_trace_degradation_and_duplication_audit.md`
- `work/theory-writing/chapters/II_agentic_session_trace_readiness_report.md`

Создай также:

```text
MANIFEST.md
VERIFY.md
RESUME.md
STATUS.md
```

`VERIFY.md` должен проверить целостность цепочки: наличие отчётов проходов, отсутствие массового восстановления пропущенных проходов, синхронизацию сопутствующих файлов и готовность результата.

После этого собери result zip из текущего каталога пакета. Если инструменты архивации недоступны, явно перечисли созданные файлы и состояние готовности.
