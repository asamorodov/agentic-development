# MANIFEST

Пакет результата главы II.

## Итоговые файлы

- `work/theory-writing/chapters/II_agentic_session_trace.md` — sha256 `2bad9622aca67e91a6341a4e5f2ba7c64056a4894ebf468e527cf30d15e54094`
- `work/theory-writing/chapters/II_agentic_session_trace_source_register.md` — sha256 `9e5485b7dfc8152417e3f5e7fd1da89065f7a6497dc9e30df1cb8a1ad50be6a6`
- `work/theory-writing/chapters/II_agentic_session_trace_fragment_usage.md` — sha256 `a70d1109ef7782ec8d443cc5da85cad54e9506f56d97fa52d7716fa3d3955576`
- `work/theory-writing/chapters/II_agentic_session_trace_atlas_usage.md` — sha256 `9972e8f94fd1ac672bc660c52ca9c87b7f4d77113aeeb62112508ba4bc260f34`
- `work/theory-writing/chapters/II_agentic_session_trace_dossier_gap_notes.md` — sha256 `57e0deffb9f51cc4dcc21402498ff9e7a90791496d90e72529478f244a2f7bad`
- `work/theory-writing/chapters/II_agentic_session_trace_external_discovery_log.md` — sha256 `c048a024a41aba9e79c6395c4caaca111a1619b5bd3ba54e3912c85231386438`
- `work/theory-writing/chapters/II_agentic_session_trace_story_anchors.md` — sha256 `3434a0433c23e0c5ab7a34d56765f5966676a91cd89e324bfcd8eb16b2e80330`
- `work/theory-writing/chapters/II_agentic_session_trace_figure_candidates.md` — sha256 `4b464a6a03770b88853bb332f978c8289408c15f830264b4b6cd895cbd580a76`
- `work/theory-writing/chapters/II_agentic_session_trace_open_questions.md` — sha256 `7fd829bdf0a477d877452e438d38f0a6a059920926c4b75679e6a2fded125547`
- `work/theory-writing/chapters/II_agentic_session_trace_degradation_and_duplication_audit.md` — sha256 `2fbc207c2faee1cf19faba3f5b370c88769aaaad334bdb1a8cf5927e05001ac9`
- `work/theory-writing/chapters/II_agentic_session_trace_readiness_report.md` — sha256 `98a3b0ac7d8d8a8d3e2693624a470fec26dce4dc83fb71848944da2368ce9637`

## Рабочие проходы

- `work/theory-writing/chapters/II_agentic_session_trace_passes/01_context_contract.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/02_skeleton_frame.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/03_fragment_salvage.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/04_story_plan.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/05_atlas_plan.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/06_dossier_gap.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/07_content_gap.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/08_content_gap.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/09_external_unfolding.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/10_visual_policy.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/11_reader_path_outline.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/12_first_synthetic_draft.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/13_fragment_integration.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/14_story_plan.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/15_external_integration.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/16_content_repair.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/17_neighbor_boundaries.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/18_source_provenance.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/19_language_1.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/20_language_2.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/21_editorial_argument.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/22_editorial_density.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/23_story_plan.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/24_entry_structure_sequence.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/25_companion_sync.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/26_style_defect_audit.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/27_selective_natural_rewrite.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/28_guarded_final_style.md`
- `work/theory-writing/chapters/II_agentic_session_trace_passes/29_final_regression.md`

## Примечание

Skeleton, карты маршрутизации и общий blueprint не изменялись.
