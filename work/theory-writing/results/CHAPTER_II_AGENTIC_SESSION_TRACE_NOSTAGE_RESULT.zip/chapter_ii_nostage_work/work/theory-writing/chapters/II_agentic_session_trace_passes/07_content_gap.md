# P07 — Карта содержательных лакун для внешнего поиска

## Общий вывод

Внутренних материалов достаточно, чтобы написать сильную главу II как теоретический текст о живой агентской сессии: trace, observation, intervention, compaction, handoff and external state. Но есть одна реальная содержательная лакуна: внутренний корпус хорошо показывает практические истории, но хуже даёт общий язык для классификации самой трассы сессии и сбоев, проявляющихся только в ходе исполнения.

Внешний поиск нужен не ради симметрии и не ради набора модных ссылок. Он должен быть ограничен двумя вопросами:

```text
1. Как в исследованиях и практических материалах описывают traces / transcripts / logs / interaction histories агентской coding-сессии?
2. Какие execution-time failures coding agents показывают только после начала работы с файлами, инструментами, браузером, тестами, PR or logs?
```

Если внешний поиск не даст более точного языка, глава может быть написана по внутренним материалам. Но без ограниченного source-pass есть риск, что глава останется в основном набором story-derived distinctions и не получит внешней понятийной опоры.

## Лакуна 1: что считать трассой сессии

Внутренние материалы дают много примеров:

- transcript Claude Code / Codex / Pi;
- команды и вывод terminal;
- browser observation, screenshot, DOM and console errors;
- Showboat document with commands and outputs;
- Rodney browser session;
- PR comments, CI, review signals;
- workflow logs and `final_output.txt`;
- handoff file, progress update, issue wrapper;
- hook output, checkpoint, task status.

Но это пока список примеров, а не классификация. Для главы нужен не полный академический обзор, а короткое различение:

```text
session trace = recorded interaction + tool/action trace + environmental observations + intermediate reasoning/decisions + produced artifacts + verification signals.
```

Возможный внешний поиск должен проверить, есть ли у SWE-chat / Programming by Chat / agent trace analysis похожие категории: messages, actions, observations, tool calls, states, artifacts, summaries, decisions, errors, human interventions.

**Нужен ли поиск:** да, ограниченно. Найти 2–4 источника, которые дают язык для session trace / interaction trace / coding-agent transcripts. Не искать всё про observability.

## Лакуна 2: стенограмма, лог, наблюдение, свидетельство

A7 даёт сильное внутреннее различение: наблюдение ориентировано на следующий ход агента, свидетельство — на решение человека о судьбе изменения. Но для главы II полезно проверить, есть ли внешние материалы, где transcript/log/traces explicitly discussed as useful but insufficient.

Нужно не доказывать очевидное, а усилить формулировку:

- transcript помогает восстановить происхождение;
- log помогает понять ход исполнения;
- observation помогает скорректировать следующий шаг;
- evidence requires claim, scope, criterion, reproducibility and owner.

**Нужен ли поиск:** частично. Если найденные источники по session trace уже покрывают эту границу, отдельный поиск не нужен. Если нет — искать narrowly: coding agent logs evidence, transcript provenance software agent, session trace verification.

## Лакуна 3: execution-time failures coding agents

Истории дают набор практических failures:

- агент буквально понял keyboard functionality;
- агент начал опасное действие вроде закрытия Chrome windows;
- браузерная правка кажется выполненной, но не проверена по маршруту;
- issue содержит AI-expanded ложный диагноз;
- агент путает порядок фаз и начинает coding before design/plan;
- migration output compiles but violates business rule coverage;
- MCP/tooling surface загрязняет контекст;
- full logs drown useful signal;
- long context carries old hypotheses and noise;
- subtask returns `done`, not transferable state.

Но это пока историями доказанные паттерны, а не общая taxonomy. Для главы II можно обойтись без внешней taxonomy, если текст останется практическим. Однако внешний источник типа `How Coding Agents Fail` может дать полезные названия или группировку: context loss, tool misuse, premature completion, hallucinated state, stale environment, poor error recovery, over-trusting generated summaries, failing to update artifacts, weak handoff.

**Нужен ли поиск:** да, но только один bounded pass. Искать источники о coding agent failures during execution, not general LLM hallucination. Если источник слишком общий, не включать.

## Лакуна 4: что должно пережить сжатие контекста

HumanLayer, Mark Erikson, Armin/Pi and PWG уже дают достаточно материала:

- сохранять не полный transcript, а current state;
- отделять useful signal from context noise;
- фиксировать decisions, corrections, learnings, next steps;
- хранить active work, blockers, verification status, handoff and quirks;
- explicitly update superseded understanding;
- создавать prime/rehydration state.

Внешний поиск здесь не обязателен. Если искать, то только в связке с session trace: какие элементы должны попасть в compaction summary or handoff. Но внутренний корпус достаточно силён, и добавление внешних источников может раздуть главу.

**Нужен ли поиск:** нет для первого черновика. Использовать внутренние материалы.

## Лакуна 5: граница с process/runtime/PWG

A6, P05 and Atlas already cover this well. Внешний поиск по workflow runtime, durable execution, observability or task graphs сейчас вреден: он уведёт главу II в IX/VII.

**Нужен ли поиск:** нет.

## Ограничение external discovery

Если следующий проход будет запускать поиск, он должен быть ограничен следующими query families:

1. `SWE-chat coding agent session trace transcript tool calls observations`
2. `Programming by Chat coding agent conversation transcript software development`
3. `How Coding Agents Fail execution failures coding agents tools logs`
4. `coding agent trace analysis tool calls observations artifacts human intervention`
5. `LLM coding agent session compaction handoff transcript summary`

Не искать широко:

- general LLM observability;
- generic software logging;
- generic human-in-the-loop AI;
- generic autonomous agents;
- broad SDLC surveys, если они не говорят о session traces or execution-time failures.

## Критерии включения внешнего источника

Источник включается в главу только если он даёт хотя бы одно из трёх:

1. Более точный язык для session trace: messages / actions / observations / tool calls / artifacts / intervention / state.
2. Хорошую классификацию failures, возникающих во время агентского исполнения.
3. Сильную границу между transcript/log and evidence/acceptance.

Источник не включается, если он только подтверждает общую мысль «агенты ошибаются» или «нужен человек». Это слишком общо и не усиливает главу.

## Рекомендуемый итог

Нужен один небольшой source discovery pass перед основным черновиком или во время его укрепления. Он должен вернуть не больше 3–5 источников и короткое решение включения:

```text
use / don't use / reserve for XI / reserve for IX / reserve for VII
```

Если поиск ничего качественного не даст, глава всё равно может быть написана без внешнего добора. Внутренний корпус уже содержит достаточно практических якорей; внешний материал нужен только для языка и классификации, а не для замены аргумента.
