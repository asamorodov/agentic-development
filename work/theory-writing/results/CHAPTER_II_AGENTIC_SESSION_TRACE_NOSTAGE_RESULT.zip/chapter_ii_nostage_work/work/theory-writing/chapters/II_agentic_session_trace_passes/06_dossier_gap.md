# P06 — Карта лакун по досье для главы II

## Общий вывод

Для главы II досье не должны становиться черновиком. Текущих входов достаточно, чтобы писать главу о сессии, трассе, вмешательстве и выживании результата. Досье нужны точечно: для уточнения фактов о минимальной обвязке, session/file memory, issue investigation, фазовом порядке и workflow-сбоях.

Методологические досье на этом этапе не требуются как основной источник. Статьи Атласа по PWG, GSD, BMAD и Kiro уже дают достаточную границу между сессией и устойчивым состоянием. Методологические досье можно открывать позже только если в черновике появится конкретная fact gap: команда, файл, статус, ограничение или source-backed detail, которую статья Атласа не покрывает.

## Armin Ronacher dossier

**Статус для главы II:** использовать точечно; сильный источник для минимальной обвязки, логов, локальной памяти, issue investigation and closure ritual.

**Что досье добавляет сверх истории:**

- точную техническую сцену вокруг `make dev`: pidfile, защита от повторного запуска, сохранение вывода process manager в файл, читаемые stack traces and port conflicts;
- критерий хорошей среды для агента: быстрый инструмент, полезный output, явное падение вместо зависания, понятная ошибка при неправильном использовании;
- практику code-as-tool-interface: JSON files, `jq`, ad hoc shell scripts, editable CDP skill вместо большого browser MCP;
- правило удаления failed automation: slash commands, hooks, print mode and subagents оцениваются по принятым результатам, а не по обещанию формы;
- Pi как tiny core with session trees, extension state and compaction;
- `/is` как investigative boundary: issue is input, not truth; read code, trace behavior, do not implement without explicit request;
- `/wr` as wrap-up boundary: changelog, exact `closes #`, staging discipline, checks and AI disclosure.

**Как использовать в главе:**

- в основном тексте достаточно двух-трёх точных деталей: `make dev`/logs как наблюдаемая среда; `/is` как процедура входа; `/wr` как процедура закрытия;
- session tree and extension state можно упомянуть только если нужен мост к handoff/compaction;
- длинный разбор MCP-критики и Pi architecture оставить вне главы II.

**Gap-status:** досье закрывает фактологическую лакуну по Armin. Дополнительный внешний поиск не нужен, если глава не будет делать более сильные claim’ы о Pi beyond issue investigation and wrap-up.

## Product Migration with Claude Code dossier

**Статус для главы II:** optional / cautionary donor. Не нужен для основной композиции, но полезен, если глава будет делать отдельный абзац о том, что длинная сессия не масштабируется до миграции без критериев отказа, проверки паритета и фазового маршрута.

**Что досье добавляет:**

- миграция как случай, где compile/test success может не означать сохранение business behavior;
- per-ticket loop: design/plan, worktrees, MR management, CI loops;
- критика migration agents через business-rule coverage;
- примеры gated pipelines: YAML plan, ограниченные роли, attempts, fixture cleanup, tests and report;
- unattended loops, `claude --print`, LSP and механический слой Claude Code как build-system-like work.

**Как использовать в главе:**

- лучше не включать в основной текст, чтобы глава II не ушла в миграции и будущую главу XI;
- можно держать как backup для фразы: «на длинных миграциях наблюдение “агент перечислил много правил” не является свидетельством полноты»;
- если использовать, то только как один контрастный пример предела сессии, не как отдельную историю.

**Gap-status:** не нужен для первого черновика главы. Вернуться к нему только если тексту не хватает сильного отрицательного примера длинной работы.

## Quix / Klaus Kode dossier

**Статус для главы II:** optional, но полезен для точной границы «порядок фаз не должен жить в памяти агента».

**Что досье добавляет:**

- исходная задача интеграций требует не только code generation, но и правильный порядок: source, sink, transform, diagnose, sandbox, logs, deploy;
- попытка увеличить prompt and MCP surface была недостаточной;
- решающий pivot: Claude Code пишет код, а deterministic Python вызывает известные API, загружает код, запускает cloud sandbox, забирает logs and drives phases;
- `WorkflowFactory`, `WorkflowContext`, serialized contexts, prompt contracts and phase lists превращают идею workflow в state machine;
- неудобная фактура: repo layout менялся, публичный нарратив в основном исходит от Quix, статус production use unclear, часть деталей требует fresh source check.

**Как использовать в главе:**

- как короткий boundary example для раздела «когда сессия путает порядок»;
- не писать о Quix как полном методе и не описывать репозиторий подробно;
- формула для черновика: «правильный ответ на часть agent failure — не ещё один длинный prompt, а обычное программное состояние вокруг агента».

**Gap-status:** полезен как backup и точная опора для phase/order. Если черновик будет использовать Quix, нужно оставить осторожную формулировку: публичная фактура сильна для механизма workflow/state machine, но слабее для выводов о реальном adoption, PR-quality and long-term use.

## Методологические досье

### PWG dossier

**Нужно ли сейчас:** нет, если глава использует PWG только как границу. Статья Атласа уже даёт достаточные понятия: work object, dependencies, owner, gate, evidence, prime, recovery and boundary against transcript/runtime.

**Когда открыть:** если в черновике потребуется точная формулировка про Beads, Dolt, claim, ready queue or source-state. Для главы II это, скорее всего, чрезмерно.

### GSD dossier

**Нужно ли сейчас:** нет. Атлас уже даёт фазовую границу: Discuss / Plan / Execute / Verify / Ship, `.planning/`, state files, structured checkpoints and stale/dirty/expired plan.

**Когда открыть:** если в черновике используется конкретная команда GSD или Nyquist/preflight. Лучше избежать.

### BMAD dossier

**Нужно ли сейчас:** нет. Атлас достаточно покрывает story as implementation contract, `sprint-status.yaml`, checkpoint preview, correct-course and evidence boundary.

**Когда открыть:** если потребуется точная фактология по `bmad-checkpoint-preview`, `correct-course` or testing modules. В II это не нужно.

### Kiro dossier

**Нужно ли сейчас:** нет. Атлас достаточно покрывает Kiro как product-native specification state: `.kiro/specs`, `.kiro/steering`, `#spec`, hooks, supervised mode, checkpoints.

**Когда открыть:** если будущий черновик будет делать конкретные claim’ы о Kiro subagents, Web Preview, governance, PBT or current documentation. Для главы II это надо избегать.

## Итоговая карта лакун

| Тема главы II | Достаточно текущих входов? | Нужно ли досье? | Решение |
| --- | --- | --- | --- |
| Сессия как локальный контекст исполнения | да | нет | писать по Skeleton, A1, P02/P03 |
| Trace as observation | да | нет | писать по A7, Simon/Arvid |
| Minimal harness, logs, file memory | частично | Armin dossier полезен | использовать точечно |
| Issue as input, not truth | частично | Armin dossier полезен | использовать `/is` коротко |
| Closure ritual / wrap-up | частично | Armin dossier полезен | использовать `/wr` коротко |
| Phase/order failure | частично | Quix dossier optional | использовать только если нужен сильный boundary example |
| Long migration failure | нет необходимости | Product Migration optional | отложить, чтобы не уйти в XI |
| Durable work state | да | методологические досье не нужны | ограничиться PWG Atlas |
| Process profile boundary | да | методологические досье не нужны | ограничиться GSD/BMAD Atlas |
| Product-native spec state | да | методологические досье не нужны | ограничиться Kiro Atlas |

## Рекомендация для следующего прохода

Писать первый черновой план главы без дополнительных досье как основного материала. Включить Armin dossier как точечный источник для двух сцен: наблюдаемая локальная среда и issue/wrap-up rituals. Quix держать как резервный пример для phase/order; Product Migration не включать в первый черновик, если глава и так держит линию через Simon, Arvid, Jökull, Armin, Peter, HumanLayer and Mark.

Главное ограничение:

```text
Досье должны закрывать fact gaps, а не заменять композицию главы.
```
