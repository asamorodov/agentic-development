# VIII — dossier gap notes

Статус: заполнено по текущему тексту главы.

## Закрытые gaps

- BMAD brownfield/investigation был тонким после первого черновика. P11 перечитал Established Projects FAQ, Project Context and Forensic Investigation, после чего BMAD-раздел получил фактуру про document-project, Quick Flow conventions, `project-context.md`, case file, confirmed/deduced/hypothesized, stronghold and hypothesis discipline.
- Визуальный слой был проверен в P12. Реальных source images для немедленной вставки не найдено; сформированы два synthetic candidates.
- Языковой слой переписан в P13: основная глава теперь написана более естественным русским, source-native terms сохранены только там, где они работают как названия/статусы/команды.
- Структурный перекос BMAD проверен в P14. Раздел сжат и возвращён к функции примера маршрутизации, но не вычищен до абстракции.

## Оставшиеся gaps

1. **Плотность BMAD.** Раздел всё ещё самый длинный. Это допустимо, потому что BMAD даёт несколько типов маршрутов в одном anchor-method, но дальнейший рост запрещён без замены менее важной детали.

2. **Визуальная вставка не выполнена.** Есть briefs для `fig-viii-process-profile-interface` and `fig-viii-billing-api-profile-routing`, но локальные SVG пока не созданы и в текст не вставлены.

3. **Source-native terminology.** В тексте остаются `story`, `workflow`, `execution`, `investigation`, `review`, `checkpoint`, `brownfield`, `gates`, `case file`, `Confirmed/Deduced/Hypothesized`. Это не ошибка само по себе, но финальный стиль-проход должен проверить каждое слово на необходимость.

4. **Mae/Shopify anchors не использованы.** Это сознательное решение текущей структуры. Если будущий проход потребует больше story evidence, лучше сначала объяснить, какой новый механизм они добавляют.

5. **Актуальность внешних docs.** BMAD/GSD документация быстро меняется. Перед публичной фиксацией нужно будет перепроверить ссылки, если между исполнением пакета и публикацией пройдет значительное время.
