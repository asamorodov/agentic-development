# MANIFEST

Result archive for Chapter VIII: `VIII_protected_process_profiles`.

Archive root intentionally contains repository-relative paths directly; there is no extra top-level wrapper folder.

## Main chapter and companion files

- `work/theory-writing/chapters/VIII_protected_process_profiles.md` — sha256 `d4def24df00cc9c2d04562f0e73fab259d75dc52b95c55019d89b7d1cde0eedd`
- `work/theory-writing/chapters/VIII_protected_process_profiles_source_register.md` — sha256 `2f4f6e0bc4c9291df87eefce7b2a17d5dd0f0a6ea11e2d44b2638423a712b308`
- `work/theory-writing/chapters/VIII_protected_process_profiles_fragment_usage.md` — sha256 `ec26e344a797f04291c6a07a6bb1d2fa48dc8f69b4951c7258adddc2de5ea629`
- `work/theory-writing/chapters/VIII_protected_process_profiles_atlas_usage.md` — sha256 `7bc3671eee50ef28696291e1f645adb96c6180e9eb5d9faaa4c8b67357e947b0`
- `work/theory-writing/chapters/VIII_protected_process_profiles_dossier_gap_notes.md` — sha256 `08a8fa4c94aa540fa34b3d35b3749ed535bb6ff502cc54135c940d9d3d15cd62`
- `work/theory-writing/chapters/VIII_protected_process_profiles_external_discovery_log.md` — sha256 `393cc9eccf4ed536864fae3787a4d4fdc792d763ee9cb794317c17d0035fca50`
- `work/theory-writing/chapters/VIII_protected_process_profiles_story_anchors.md` — sha256 `7d359428f2c0b70f71d8d7dbfb940b6bc715b6c7c0af6ea4a14dab54ab9a9fd4`
- `work/theory-writing/chapters/VIII_protected_process_profiles_figure_candidates.md` — sha256 `daedebfe0af092fd20acf351704c399c182394d3a0caa69ea51944bf5ef4bf47`
- `work/theory-writing/chapters/VIII_protected_process_profiles_open_questions.md` — sha256 `227bd8a41a5e7ddf386ac4b1d01defc8776f9ac633549bd54e1fc6e5fa871c58`
- `work/theory-writing/chapters/VIII_protected_process_profiles_degradation_and_duplication_audit.md` — sha256 `6a8fb506078c0274fe3caf2da566d73d219fa20f29a83127c121ef152ef12863`
- `work/theory-writing/chapters/VIII_protected_process_profiles_readiness_report.md` — sha256 `efe2c7155b0ef599a9267a0567650ff83ef223a7c8e00bbcd1048e70f7665895`

## Pass reports

- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/01_01_context_and_boundary.md` — sha256 `66fc37e937da48b001bac70d5b3de67b101f3c7498cf9d8c0184a61c01001f96`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/02_02_input_corpus_map.md` — sha256 `6a3dadcb324d1ca3f6a656605c6bbf6817703736d8870644f971188ae55883b8`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/03_03_source_register_seed.md` — sha256 `86f49ba0fa8818a0860982de7f33c562c197e1b7809d78350de01f604ed81a23`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/04_04_external_discovery.md` — sha256 `48fe0545985b8b94f0a051806c143e683ff775b4c80c1fe6a70883f6f2e0f39d`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/05_05_chapter_frame.md` — sha256 `6e4464d923ab9734d3fb35d7f76dc720d1c07743fca47b05cdffb4716283fed6`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/06_06_cross_example.md` — sha256 `f97ca3fde0784a6d467649b825a6b95ad40b3498720c1f89efd2abee98e3f472`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/07_07_source_family_deepening.md` — sha256 `3bf519ef3f556ac1184209f7ee83c2835a5e6e4a44ebb20208ebf776dbdaa995`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/08_08_interface_and_current_practice.md` — sha256 `0ef43aa8e2622d29ab12de324e9e7762636e6f3e76670f70b8c2e73c74f6831c`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/09_09_argument_skeleton.md` — sha256 `1bd2f00301131867524bdab935f5d98464f9e032553f325fd108920950d89692`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/10_10_full_draft.before_p13.md` — sha256 `dfa34c64f52e1a728aa07cab3b22666083a4471e4894d6cfb720b547bce56348`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/10_10_full_draft.md` — sha256 `d4def24df00cc9c2d04562f0e73fab259d75dc52b95c55019d89b7d1cde0eedd`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/11_11_active_material_intake.md` — sha256 `7a4898741e1def9b7f07d5d7cc384cf9a9df3f0821f2d5c42e4223696686449d`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/12_12_visual_layer.md` — sha256 `28acf04c98785cace273f7592df8a571cece2865b8be170feb61d9aa1fff6b3b`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/13_13_natural_russian_rewrite.md` — sha256 `7ff0fb0dc3f290c181c790fca70a6137a18580a1c1a7b7fb39d082602d4d92eb`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/14_14_structure_and_individuality.md` — sha256 `1a470f14438ec62b7036064867735a53239878a3654f79567bb7c1bbd3b0a664`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/15_15_companion_files.md` — sha256 `fe071a11e01ab57bfda45b0027fc2ad62d6f173404581f4af6160557edeae731`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/16_16_final_revision.md` — sha256 `0f44d39c3dc03d8e7c697d0d91a829e27195a736bf18ee388af299fa277c00be`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/17_17_readiness_report.md` — sha256 `efe2c7155b0ef599a9267a0567650ff83ef223a7c8e00bbcd1048e70f7665895`
- `work/theory-writing/chapters/VIII_protected_process_profiles_passes/18_final_package_readiness.md` — sha256 `e01233d537e433a262f5219c1d980e9340c82cf5684ac3f16cd19e5867d2e899`

## Build notes

- `MANIFEST.md`, `VERIFY.md`, `RESUME.md` and `READINESS.md` are root-level result metadata files.
- Source documents, skeletons, routing maps and Atlas articles are not included as changed outputs.
