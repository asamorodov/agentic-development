# READINESS

Status: ready as current-package output.

The main chapter explains why a restored work node still needs a protected process profile before an agent continues work. It distinguishes reading state from having the right to act, and it shows how the same `billing/API` work node can require different next routes: story creation, story execution, brownfield investigation, `correct-course`, verification or human checkpoint.

The chapter is not a catalog of sources: GSD, BMAD, Jesse Vincent, HumanLayer, Matt Pocock skills, Beads and Gas Town are used as support for the chapter's own explanatory move.

Figures were not inserted into the chapter. Figure candidates are recorded for later publication work.

Ready files are listed in `MANIFEST.md`; mechanical checks are in `VERIFY.md`; repository handoff notes are in `RESUME.md`.
