# RESUME

## What this result contains

This archive contains the finished current-package output for Chapter VIII:

- the main chapter file `work/theory-writing/chapters/VIII_protected_process_profiles.md`;
- companion files for sources, fragments, Atlas usage, dossiers, story anchors, figure candidates, open questions, external discovery and degradation audit;
- all pass reports from the package execution;
- `MANIFEST.md`, `VERIFY.md` and `READINESS.md`.

## What to apply to the main repository

Apply the files under:

```text
work/theory-writing/chapters/
```

The archive is laid out with repository-relative paths at the root, so these files can be copied as an overlay into the repository root.

## State files to update after applying

After the chapter output is accepted and applied, update the main repository state files:

```text
work/discourse.md
work/theory-writing/WORKING_DOCUMENTS_MAP.md
work/APPLY_NOTES.md
```

Minimum update to record:

- Chapter VIII `VIII_protected_process_profiles.md` has been produced as the current package result.
- The chapter's own axis: persistent work state/PWG is not enough; continuation needs a protected process profile that selects the correct mode of work.
- Main bridges: Chapter IX should take up execution environment, permissions, worktrees, sandbox/tools/hooks/MCP access; Chapter X should take up multi-stream working environment and orchestration.
- Companion files and pass reports were produced with the chapter and should be kept alongside it.

## Not changed by this package

This package did not change Skeleton, routing maps, blueprint, original Atlas articles or source dossiers.

## If work resumes

Resume from the finished chapter and readiness report, not from intermediate drafts. The strongest remaining editorial decision is whether to turn `fig-viii-process-profile-interface` into a publication figure.
