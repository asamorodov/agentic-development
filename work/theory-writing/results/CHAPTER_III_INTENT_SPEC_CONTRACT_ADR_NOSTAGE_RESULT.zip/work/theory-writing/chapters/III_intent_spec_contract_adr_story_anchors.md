# III. Story anchors

| Story | Use in chapter | Status |
| --- | --- | --- |
| Boris Tane | Opening example of `research.md` / `plan.md` before code. | Good. Does not dominate. |
| HumanLayer | Harness/context support for specification as working form. | Good. No full harness chapter. |
| Matt Pocock | PRD, vertical slices, `progress.txt`, marker of completion. | Good. Some source-native terms remain. |
| Mike McQuaid | Prepared AI work vs accepted project work. | Good. No Sandvault tutorial. |

## Integration rule

Story anchors are used to make distinctions concrete. They should not become the chapter spine and should not expand into story summaries.
