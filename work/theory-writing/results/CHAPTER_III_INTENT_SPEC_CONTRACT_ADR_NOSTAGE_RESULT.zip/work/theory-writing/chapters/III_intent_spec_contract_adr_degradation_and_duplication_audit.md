# III. Degradation and duplication audit

## Preserved

- Chapter remains conceptual, not a method catalog.
- Specification, contract and ADR are separated.
- ADR/status boundary is strong.
- Generated/reconstructed ADR candidate boundary is strong.
- `Confirmation` does not become an evidence chapter.
- SPDD is a bridge to IV, not a deep treatment.
- PWG / work-state is only bridged.
- Design Decision Gate remains a pattern for stopping automatic flow, not a governance chapter.

## Remaining risks

- Section 2 names SPDD/Spec Kit/CSDD in one paragraph; responsibility framing must keep leading.
- Section 4 contains several examples; do not expand it into a tool list.
- Section 7 uses one external AI/ADR paper; avoid adding more unless the chapter scope changes.
- Some source-native terms remain English; preserve exact names, but avoid adding new English glue.

## Duplication check

The chapter does not duplicate chapter IV. SPDD is introduced only as the next deep case. The chapter also does not duplicate Evidence or Authority chapters: `Confirmation`, CODEOWNERS and Design Decision Gate remain boundary examples.
