# P08 — внешний поиск по содержательным лакунам

## Итог поиска

Внешний поиск подтвердил исходную оценку P07: главе III не нужен новый методический слой. Нужна точная опора для нескольких различений, которые иначе выглядели бы как внутренний пересказ: жизненный цикл ADR, `Confirmation` как ограниченный план подтверждения, архитектурные проверки как частичные fitness functions, `CODEOWNERS` как review routing, and generated/reconstructed ADR as candidate work rather than decision authority.

Главное ограничение для черновика: не превращать найденные источники в библиографический обзор. В основной текст должны войти только те ссылки, которые поддерживают рабочее различение главы.

## Integrate now — источники, которые прямо нужны главе

### 1. Nygard / Cognitect — ADR как компактная запись решения

Источник: [Michael Nygard, “Documenting Architecture Decisions”](https://www.cognitect.com/blog/2011/11/15/documenting-architecture-decisions).

Что использовать:

- ADR как короткая запись, рассчитанная на будущего разработчика, который пришёл в проект после принятия решения;
- минимальная форма `Title / Context / Decision / Status / Consequences`;
- `Context` stores the forces at play, `Decision` states response to those forces, `Status` может быть `proposed`, `accepted`, `deprecated`, `superseded`.

Как встроить:

- в первом ADR-блоке главы: ADR нужен не потому, что “архитектура любит документы”, а потому, что решение должно пережить исчезновение исходной беседы;
- не переносить практические советы про файл, нумерацию and one-two-page rule, если они не понадобятся для конкретного примера.

### 2. Fowler — accepted ADR не переписывается задним числом

Источник: [Martin Fowler, “Architecture Decision Record”](https://martinfowler.com/bliki/ArchitectureDecisionRecord.html).

Что использовать:

- ADR as record in a decision log;
- статус `proposed / accepted / superseded`;
- accepted ADR should not be reopened and rewritten; when decision changes, it is superseded by a new ADR.

Как встроить:

- в блоке “decision memory vs living instruction”: accepted ADR нельзя “улучшать” как README;
- это поддерживает тезис о замене через новую запись, а не о ретроактивном исправлении прошлого.

### 3. AWS Prescriptive Guidance — ADR как reviewed process artifact

Источники:

- [AWS Prescriptive Guidance, “ADR process”](https://docs.aws.amazon.com/prescriptive-guidance/latest/architectural-decision-records/adr-process.html);
- [AWS Prescriptive Guidance, “Best practices for ADRs”](https://docs.aws.amazon.com/prescriptive-guidance/latest/architectural-decision-records/best-practices.html).

Что использовать:

- после принятия ADR должен оставаться immutable; изменение решения оформляется новым ADR, который supersedes previous record;
- process includes review, acceptance/rejection/rework, owner/stakeholder discipline;
- history of decisions should be preserved.

Как встроить:

- как второй источник после Fowler для дисциплины жизненного цикла;
- не уходить в AWS workflow подробно. Нужна только мысль: decision memory получает силу через статус, review and replacement discipline.

### 4. MADR — `Confirmation` как место будущей проверки

Источник: [MADR — Markdown Architectural Decision Records](https://adr.github.io/madr/).

Что использовать:

- MADR extends the basic ADR shape with decision drivers, considered options, pros/cons, consequences and confirmation;
- `Confirmation` belongs to the ADR template as an explicit place where future compliance/implementation can be checked.

Как встроить:

- как мост от ADR к контракту: ADR может не только объяснить выбор, но и указать, каким образом его соблюдение будет подтверждаться;
- важно сразу ограничить: `Confirmation` is not “one test that proves the architecture”; it is a planned confirmation surface, where each signal proves only what it can prove.

### 5. Evolutionary architecture / architecture fitness functions — ограниченная проверяемость архитектурных свойств

Источники:

- [Evolutionary Architecture, “What is a fitness function?”](https://evolutionaryarchitecture.com/);
- [Thoughtworks / Neal Ford et al., “Building Evolutionary Architectures” sample chapter](https://www.thoughtworks.com/content/dam/thoughtworks/documents/books/building-evolutionary-architectures/Building_Evolutionary_Architectures_Sample_Chapter.pdf).

Что использовать:

- architecture fitness function as objective integrity assessment of one or more architectural characteristics;
- fitness functions can protect architectural dimensions from unwanted breakage when the system changes;
- many architectural properties can be made testable or at least periodically assessable, but not all architectural judgment reduces to tests.

Как встроить:

- в абзац о `Confirmation` / contract: часть решения можно закрепить структурным правилом, contract check, performance/availability signal, dependency constraint or review gate;
- сразу добавить границу `does_not_prove`: такая проверка подтверждает конкретное свойство, а не весь смысл решения.

### 6. GitHub CODEOWNERS — review routing, not authority itself

Источники:

- [GitHub Docs, “About code owners”](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-code-owners);
- [GitHub Docs, “Managing a branch protection rule”](https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/managing-a-branch-protection-rule).

Что использовать:

- `CODEOWNERS` can automatically request review from code owners when a pull request modifies owned files;
- branch protection can require review from code owners before merge.

Как встроить:

- только как пример review routing in confirmation plan;
- не превращать в главу XII about authority. Формулировка должна быть осторожной: code owner review can route responsibility to a named group, but it does not by itself prove architectural correctness.

### 7. LLM / ADR research — generated or reconstructed ADR as candidate

Источники для осторожного использования:

- [“Can LLMs Generate Architectural Design Decisions? — An Exploratory Empirical Study”](https://arxiv.org/abs/2403.01709);
- [“DRAFT-ing Architectural Design Decisions using LLMs”](https://arxiv.org/abs/2504.17882);
- [“Context Matters: Large Language Models for Context-Aware Architectural Design Decision Generation”](https://arxiv.org/abs/2601.00624);
- [“AgenticAKM: Agent-based Architectural Knowledge Management”](https://arxiv.org/abs/2601.02059);
- [“Evaluating LLMs for Detecting Architectural Decision Violations in Code”](https://arxiv.org/abs/2603.00645).

Что использовать:

- исследования подтверждают саму возможность LLM-assisted drafting / generation / reconstruction / violation detection;
- результаты неоднородны and context-dependent;
- даже когда система помогает создать ADR or detect decision violation, this does not transfer decision authority to the model.

Как встроить:

- максимум один короткий абзац в блоке about candidate records;
- не давать обзор литературы;
- основной вывод главы: `origin: agent-drafted` or `origin: reconstructed` is provenance, not status. Until responsible review accepts it, the record remains candidate evidence.

## Source register only — полезно, но не тащить в основной текст III

### Contract testing / API compatibility tools

`Pact`, `oasdiff`, `can-i-deploy`, OpenAPI validators and similar tools can illustrate confirmation of interface contracts, but chapter III would become too tool-heavy if they enter the main line. Keep for chapter XI or a Handbook-style technical card unless the draft needs one tiny example.

### ArchUnit / NetArchTest / dependency-cruiser

These are useful examples of structural architectural tests. They may appear as parenthetical examples only if the text needs concreteness. Do not list them as method coverage.

### ADR Sync / Mneme / Design Decision Gate / internal agent gates

These are valuable for operational projection, but chapter III should state the pattern rather than survey products:

```text
accepted ADR → active decision set → short operational projection → agent context / hook → deterministic checks where possible → human review where judgment is required
```

Detailed mechanics belong to Atlas, Handbook, or a future implementation chapter.

## Future debt — не решать в этой главе

### Full architecture governance

Не искать дальше general architecture governance, architecture review boards, enterprise decision process or open-source maintainer policy. This would pull chapter III toward XII.

### Full CSDD/security traceability

External sources on compliance matrices, controls and secure SDLC are not needed now. CSDD already provides the local example; deep treatment belongs to security/governance material, not to the intent/spec/ADR chapter.

### Full AI/ADR literature review

The AI/ADR papers are useful as a boundary proof that LLM-assisted ADR work exists. They should not turn the chapter into a survey of LLM architectural knowledge management. If the draft needs only one source, use the empirical generation paper or DRAFT as support for “drafting assistance”, and keep the rest in reserve.

## Final integration rule for the draft

Use no more than 8–10 external links in the main chapter. The best core set is:

1. Nygard/Cognitect for minimal ADR form and status;
2. Fowler for accepted/superseded lifecycle;
3. AWS ADR process/best practices for immutability and reviewed process;
4. MADR for `Confirmation`;
5. Evolutionary architecture / fitness functions for partial objective confirmation;
6. GitHub `CODEOWNERS` docs if ownership routing appears;
7. one AI/ADR paper only if the candidate-record section needs outside support.

Everything else remains source register material.

## Статус

Публикационные лакуны закрыты. Для черновика теперь есть внешний источник на каждое load-bearing различение: ADR as decision memory, accepted/superseded lifecycle, confirmation as limited evidence plan, partial architectural checks, review routing and generated/reconstructed ADR as candidate rather than accepted authority.
