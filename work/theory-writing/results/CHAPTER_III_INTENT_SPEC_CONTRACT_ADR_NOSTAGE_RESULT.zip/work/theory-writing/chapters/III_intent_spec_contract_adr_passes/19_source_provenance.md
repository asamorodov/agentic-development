# P19 — проверка источников и происхождения утверждений

## Finding

`13_first_synthetic_draft.md` currently contains no inline external links. That is acceptable for a synthetic draft, but not for publication-ready chapter. Next drafts must attach primary sources to load-bearing claims, not cite internal dossiers or Atlas reports as public evidence.

## Source policy for this chapter

Use primary or near-primary sources for public claims:

- ADR practice: Nygard, Fowler, MADR, AWS;
- `Confirmation`: MADR template;
- architecture fitness functions: evolutionaryarchitecture.com / Ford et al.;
- `CODEOWNERS`: GitHub Docs;
- generated/design-decision drafting by LLMs: arXiv papers only as support for drafting possibility;
- story anchors: source links already live in story chapters; in this chapter, use names as corpus anchors unless publication requires cross-links.

Do not cite:

- internal dossiers as external proof;
- previous pass files;
- Atlas theory-links files;
- this package’s planning outputs;
- memory of earlier chats.

## Required citation map for next draft

| Claim type | Primary source to attach | Notes |
| --- | --- | --- |
| Minimal ADR form with `Context`, `Decision`, `Status`, `Consequences` | Michael Nygard, “Documenting Architecture Decisions” — <https://www.cognitect.com/blog/2011/11/15/documenting-architecture-decisions> | Use first ADR section. |
| ADR as short decision-log record / historic record | Martin Fowler, “Architecture Decision Record” — <https://martinfowler.com/bliki/ArchitectureDecisionRecord.html> | Use lightly; avoid duplicating Nygard. |
| Accepted ADR immutable; new decision supersedes old ADR | AWS ADR process — <https://docs.aws.amazon.com/prescriptive-guidance/latest/architectural-decision-records/adr-process.html> | Strongest public source for immutability and lifecycle. |
| Preserve ADR history / keep old ADR in decision log | AWS best practices — <https://docs.aws.amazon.com/prescriptive-guidance/latest/architectural-decision-records/best-practices.html> | Use only if needed; process page may be enough. |
| `Confirmation` in ADR template | MADR template — <https://raw.githubusercontent.com/adr/madr/4.0.0/template/adr-template.md> and overview <https://adr.github.io/madr/> | Prefer template for exact `Confirmation` field. |
| Fitness function as objective integrity assessment | Evolutionary Architecture precis — <https://evolutionaryarchitecture.com/precis.html> | Use in `Confirmation` section only. |
| CODEOWNERS requests review and branch protection can require owner review | GitHub Docs — <https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-code-owners> and <https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/managing-a-branch-protection-rule> | Use only if CODEOWNERS stays. |
| LLMs can assist ADD/ADR generation, but not human-level/authority | Dhar et al. 2024 — <https://arxiv.org/abs/2403.01709> | One source enough; do not survey. |
| Simple prompting not enough; DRAFT aids architects in drafting ADDs | DRAFT paper — <https://arxiv.org/abs/2504.08207> | Optional if the word “drafting” needs support. |

## Claims that do not need direct external citation

These are theoretical claims of this chapter, grounded by the whole argument rather than one external source:

- intent is not specification;
- specification becomes working when it changes next permitted action;
- contract is narrower than specification;
- passing a contract check does not satisfy all intent;
- origin is not status;
- prepared AI work is not accepted project work;
- after execution begins, work-state persistence is separate from specification/contract/ADR.

These can be supported by examples and sources, but should not pretend to come from a single authority.

## Generated/reconstructed ADR provenance rule

If final text mentions LLM-generated or reconstructed ADR, it must mark status explicitly:

```text
agent-drafted / reconstructed record = candidate/proposed artifact until reviewed and accepted.
```

Suggested wording:

```text
LLM research supports the practical possibility of drafting or generating decision text, but this is evidence about drafting capability, not about project authority. The record’s `origin` may be `agent-drafted`; its `status` remains `proposed` until the responsible process accepts it.
```

Do not cite AI/ADR research as proof that LLM can accept architectural decisions.

## Design Decision Gate / operational projection provenance rule

If the chapter uses Design Decision Gate, use it as a local pattern name, not as sourced product claim unless a primary source is introduced later.

Required boundary:

```text
operational projection is derivative of accepted ADR; it must carry backlink, status and scope.
```

No need to cite internal dосье. Treat it as the chapter’s proposed pattern.

## Link density recommendation

Main chapter should not exceed about 8–10 external links. Preferred final set:

1. Nygard;
2. Fowler;
3. AWS process;
4. MADR template;
5. evolutionary architecture;
6. GitHub CODEOWNERS only if used;
7. GitHub branch protection only if used;
8. one AI/ADR paper.

If the chapter needs fewer, omit optional links rather than add source noise.

## Status

Source provenance check complete. Current draft lacks links, so publication pass must add source links in-line. All ADR claims can be grounded in Nygard/Fowler/MADR/AWS; generated/reconstructed ADR must be framed as candidate/proposed until human/process acceptance.
