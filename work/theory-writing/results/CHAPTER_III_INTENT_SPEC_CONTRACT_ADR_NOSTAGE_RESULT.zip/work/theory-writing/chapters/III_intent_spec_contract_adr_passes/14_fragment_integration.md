# P14 — интеграция фрагментов A2/A3/B1/C1

## Цель проверки

Первый синтетический черновик уже держит главную линию: намерение получает носитель, спецификация управляет делегированием, контракт выделяет проверяемую часть, ADR хранит решение and status, generated/reconstructed record remains candidate. Но при сверке с A2/A3/B1/C1 видны несколько мест, где нужно усилить или точнее развести обязанности.

Эта проверка переносит смысл, не готовые абзацы.

## A2 — specification / contract / ADR

### Что уже перенесено хорошо

Черновик сохранил основные различения A2:

- intent vs specification;
- specification vs checkable contract;
- contract vs evidence;
- ADR vs living instruction;
- origin vs status for generated/reconstructed ADR;
- `Confirmation` as bridge, not proof.

Особенно удачно сохранена линия: generated ADR can look convincing but remains candidate until accepted. Это соответствует A2 status/origin grid.

### Что нужно усилить

#### 1. Подмены артефактов

A2 явно держал матрицу подмен: каждый артефакт опасен не сам по себе, а когда начинает выполнять чужую работу.

В черновике это есть, но рассыпано по разделам. Во второй редакции стоит добавить более плотный абзац ранним местом:

```text
Проблема начинается не тогда, когда у проекта мало артефактов, а когда один артефакт незаметно получает полномочия другого: план выглядит как принятое решение, зелёный тест — как архитектурное объяснение, ADR — как текущая инструкция агенту, reconstructed ADR — как исторический факт.
```

Этот абзац поможет читателю сразу увидеть, почему глава разводит формы.

#### 2. Проверочный контракт не должен становиться oracle of truth

A2 сильнее подчёркивал, что check/oracle can be gamed or can miss the intention. В черновике контракт описан как form of debt and future evidence, но нужно точнее сказать: passing the contract does not mean satisfying the whole specification.

Добавить в contract/Confirmation zone:

```text
Проверочный контракт должен быть связан со спецификацией обратной ссылкой. Иначе агент может оптимизировать под наблюдаемый сигнал and leave the actual intention behind.
```

#### 3. Operational projection should remain derivative

Черновик ввёл operational projection, но можно усилить A2-rule: projection has no independent authority. It is a derivative of accepted ADR and must contain backlink/status/scope.

Добавить:

```text
Если короткая проекция не содержит ссылку на исходный ADR, статус and область применения, она быстро становится новой неподконтрольной инструкцией.
```

## A3 — protected profiles without method catalog

### Что уже перенесено хорошо

Черновик не превратил SPDD, Spec Kit, CSDD and TDAD in catalog. Он использует их как examples of specification surfaces and transitions. Это соответствует A3 warning.

### Что нужно усилить

#### 1. Specification as permission to act

A3 сильнее формулировал вопрос: какой артефакт получает право управлять действием агента. В черновике это есть через “менять поведение следующего шага”, но можно сделать опорной фразой:

```text
Спецификация становится рабочей не в момент, когда она написана, а в момент, когда она меняет право следующего действия агента.
```

Эта формула хорошо связывает A3 and будущую XII, without turning III into governance.

#### 2. Protected profiles

A3 distinguishes method profiles:

- SPDD — structured prompt and safeguards;
- Spec Kit — transitions between spec/plan/tasks;
- CSDD — higher-order rules and traceability;
- TDAD — tests/specification boundary.

В черновике они названы, but CSDD traceability is too compressed. Add one sentence:

```text
В CSDD верхнее правило становится рабочим только тогда, когда оно проходит в конкретные files, tasks, reviews and evidence; иначе Constitution Check остаётся декларацией.
```

Do not add details.

## B1 — SPDD as bridge to IV

### Что уже перенесено хорошо

Переход к IV есть и правильно сдержан: SPDD будет deep case, current chapter only sets responsibilities.

### Что нужно усилить

B1 contained stronger SPDD-specific distinction: prompt as delivery artifact and post-implementation sync. In conclusion the current draft mentions API-test, review, prompt update and sync, but it could better prepare the next chapter by naming what SPDD adds beyond this chapter:

```text
SPDD интересен не тем, что добавляет ещё один шаблон спецификации, а тем, что делает промпт поставляемым артефактом and forces later synchronization between prompt and code.
```

This should remain in transition, not main body.

### What not to add

Do not import B1 details about `/spdd-story`, `/spdd-analysis`, `/spdd-api-test`, `/spdd-code-review`, `/spdd-prompt-update` and `/spdd-sync` into chapter III. The current draft already uses enough.

## C1 — specification → working state / PWG boundary

### Что уже перенесено хорошо

Черновик has a boundary to future evidence and authority. It says specification/contract/ADR prepare work but do not finish lifecycle.

### Что нужно усилить

C1’s strongest contribution is the intermediate failure: document exists, continuation state does not. Current draft says this indirectly through session loss and `progress.txt`, but should sharpen the transition boundary:

```text
После начала исполнения появляется новый объект: состояние работы над изменением. Спецификация говорит, что должно быть сделано; ADR говорит, почему решение принято; контракт говорит, что проверить. Но ни один из них сам по себе не хранит, кто сейчас владеет узлом, какая проверка уже привязана, какая задача заблокирована, какой источник найден but not integrated, and whether another agent can safely continue.
```

This should appear near the end, as bridge to later PWG chapter, not dominate III.

### Why this matters here

Without this sentence, chapter can look like spec/contract/ADR solve continuation. C1 reminds: they solve only pre-execution and decision-memory roles; working-state persistence is a separate layer.

## Specific repair actions for next draft

1. Add early paragraph about artifact substitutions.
2. Add sentence: specification becomes working when it changes the next permitted action.
3. Add contract/oracle warning: passing the check does not satisfy whole specification.
4. Add CSDD one-sentence traceability boundary.
5. Add projection discipline: backlink/status/scope or the projection becomes uncontrolled instruction.
6. Add C1 bridge: after execution begins, PWG/work-state is needed and is not covered by spec/contract/ADR.
7. Strengthen final SPDD transition: prompt as delivery artifact and sync after code.

## What to preserve from current draft

- Opening from post-session failure is good.
- Boris/HumanLayer/Pocock/Mike anchors are proportionate.
- `Confirmation` section is clear and should not expand into evidence chapter.
- ADR section correctly uses Nygard/Fowler/AWS without becoming tutorial.
- Generated ADR boundary is strong; keep it central.

## Status

Fragment integration check complete. No need to rewrite from scratch. Next pass should repair by insertion and tightening, not by changing chapter architecture.
