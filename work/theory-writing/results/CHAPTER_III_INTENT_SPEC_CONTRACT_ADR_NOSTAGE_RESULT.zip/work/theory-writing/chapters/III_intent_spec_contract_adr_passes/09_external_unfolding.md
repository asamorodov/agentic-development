# P09 — раскрытие и решение по внешним источникам

## Принцип отбора

Источники прочитаны не как повод расширить главу III, а как проверка нескольких узких опор. Решение по каждому источнику дано в одном из четырёх статусов:

- **встроить сейчас** — источник прямо поддерживает различение главы;
- **реестр источников** — источник полезен, но в тексте III нужен только как резерв;
- **отложить для XI/XII** — источник открывает большую тему свидетельств, управления или права на действие;
- **отклонить** — источник не добавляет точности к этой главе.

## 1. Michael Nygard / Cognitect — Documenting Architecture Decisions

Ссылка: <https://www.cognitect.com/blog/2011/11/15/documenting-architecture-decisions>

### Решение

**Встроить сейчас.**

### Что источник реально даёт главе

Nygard нужен как первичная опора для минимального ADR. В источник попадают именно те элементы, которые важны для главы III:

- `Decision` is stated as “We will …” response to contextual forces;
- `Status` может быть `proposed`, `accepted`, `deprecated`, `superseded`;
- if a later ADR changes or reverses a decision, old record is marked and references replacement;
- `Consequences` фиксируют новый контекст после решения, including positive, negative and neutral consequences;
- ADR пишется как conversation with a future developer.

### Как использовать

Вставить в основной ADR-блок как базовую форму decision memory. Не пересказывать весь шаблон. Нужны `Context / Decision / Status / Consequences` and the future-developer framing.

## 2. Martin Fowler — Architecture Decision Record

Ссылка: <https://martinfowler.com/bliki/ArchitectureDecisionRecord.html>

### Решение

**Встроить сейчас, но вторым источником после Nygard/AWS.**

### Что источник реально даёт главе

Fowler полезен не столько как шаблон, сколько как современное подтверждение лёгкой формы ADR and decision log. Важнее всего:

- ADR is a short record in a decision log;
- decision log explains why things turned out as they did;
- brevity matters: ADR should be short and link supporting material rather than absorb it;
- context changes can trigger reevaluation.

### Как использовать

Использовать для тезиса, что ADR is not a living omnibus document. Он должен объяснять why and preserve historic record. Дисциплину immutability/superseding лучше подтверждать AWS process, потому что там это сформулировано прямее.

## 3. AWS Prescriptive Guidance — ADR process / Best practices

Ссылки:

- <https://docs.aws.amazon.com/prescriptive-guidance/latest/architectural-decision-records/adr-process.html>
- <https://docs.aws.amazon.com/prescriptive-guidance/latest/architectural-decision-records/best-practices.html>

### Решение

**Встроить сейчас.**

### Что источник реально даёт главе

AWS очень хорошо закрывает то место, где глава может иначе скатиться в “ADR как заметка”. В источнике есть всё нужное для lifecycle discipline:

- ADR has states and lifecycle;
- collection of ADRs creates a decision log;
- accepted ADR becomes immutable;
- if new insight requires a different decision, new ADR is proposed, accepted and then supersedes the previous ADR;
- owner, review, comments, accepted/rejected/rework route and timestamp/stakeholders after acceptance;
- old ADR remains in decision log.

### Как использовать

Это главный источник для блока “accepted memory cannot be silently rewritten”. Сформулировать осторожно: такая дисциплина показывает, как decision memory differs from a continuously edited instruction file. Не переносить весь AWS-процесс в главу.

## 4. MADR 4.0.0 template — Confirmation

Ссылки:

- overview: <https://adr.github.io/madr/>
- template: <https://raw.githubusercontent.com/adr/madr/4.0.0/template/adr-template.md>

### Решение

**Встроить сейчас.**

### Что источник реально даёт главе

MADR нужен прежде всего из-за `Confirmation`. В шаблоне confirmation asks how implementation/compliance with ADR can or will be confirmed, and gives examples such as design/code review or a test with a library like ArchUnit.

Дополнительно MADR reinforces richer ADR shape:

- decision drivers;
- considered options;
- outcome;
- consequences;
- more information / confidence / revisit triggers.

### Как использовать

`Confirmation` should become the bridge from ADR to contract/evidence. Но глава должна добавить своё ограничение: confirmation is a planned surface of partial evidence. A design review, code review or test confirms only the thing it can observe. It does not prove the whole architecture or the correctness of original intent.

## 5. Evolutionary Architecture — architecture fitness functions

Ссылка: <https://evolutionaryarchitecture.com/precis.html>

### Решение

**Встроить сейчас как короткое подкрепление, не как отдельную тему.**

### Что источник реально даёт главе

Fitness function is defined as an objective integrity assessment of architectural characteristic(s). Источник полезен потому, что он даёт язык для ограниченной проверяемости архитектурного решения:

- system can change in a way that accidentally harms an architectural concern;
- fitness function defines what “better” or “still acceptable” means for a chosen characteristic;
- fitness functions include tests, metrics and other practices;
- continuous verification helps important qualities not degrade.

### Как использовать

Один абзац inside `Confirmation`/contract section. Пример: accepted decision may produce a structural rule, metric, dependency constraint, rollout condition or review requirement. Это объясняет, как часть архитектурного намерения becomes checkable. Не разворачивать evolutionary architecture как отдельную школу.

## 6. GitHub Docs — CODEOWNERS and branch protection

Ссылки:

- <https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-code-owners>
- <https://docs.github.com/en/repositories/configuring-branches-and-merges-in-your-repository/managing-protected-branches/managing-a-branch-protection-rule>

### Решение

**Встроить сейчас только если draft uses CODEOWNERS as example; иначе source register.**

### Что источник реально даёт главе

GitHub docs support a narrow claim:

- a `CODEOWNERS` file can assign owners to paths;
- if it is on the base branch, code owners receive review requests for pull requests affecting owned files;
- branch protection can require review from Code Owners before merge.

### Как использовать

Если `CODEOWNERS` входит в текст, он должен быть example of routing responsibility, not proof of architectural correctness. It can support a `Confirmation` plan: “changes touching this decision route to named owners”. The governance/authority analysis belongs to XII.

## 7. LLM-generated ADD/ADR research — 2024 exploratory study

Ссылка: <https://arxiv.org/abs/2403.01709>

### Решение

**Встроить сейчас в одну осторожную фразу or keep as source register.**

### Что источник реально даёт главе

The paper frames ADR as key artifact in Architectural Knowledge Management and tests whether LLMs can generate design decisions from context. Its useful finding for this chapter is limited:

- LLMs can generate relevant/accurate design decisions in some settings;
- results fall short of human-level performance;
- further research is required.

### Как использовать

Only as support for “LLM-assisted ADR drafting is plausible”. It must not become “LLM can decide architecture”. The chapter’s own distinction should remain stronger: generation capability concerns `origin`, not `status`.

## 8. DRAFT-ing Architectural Design Decisions using LLMs

Ссылка: <https://arxiv.org/abs/2504.08207>

### Решение

**Реестр источников; optionally one support line if candidate-record paragraph needs it.**

### Что источник реально даёт главе

The abstract says simple prompting does not produce quality ADDs; few-shot, RAG and fine-tuning improve generation; DRAFT can aid architects in drafting ADDs.

### Как использовать

This source is good for the word “drafting”. It supports the exact boundary: model output can aid architects, not replace responsible acceptance. But if the main chapter already cites the 2024 empirical study, DRAFT can remain in register.

## 9. Context Matters / AgenticAKM / violation detection papers

Ссылки:

- Context-aware generation: <https://arxiv.org/abs/2601.00624>
- AgenticAKM: <https://arxiv.org/abs/2601.02059>
- Violation detection: <https://arxiv.org/abs/2602.07609>

### Решение

**Отложить для XI/XII/source register, not main III.**

### Что источники реально дают

These papers open larger questions:

- context engineering for ADR generation;
- agent-based architectural knowledge management;
- LLM support for detecting architectural decision violations;
- limits: explicit code-inferable decisions are easier, implicit/deployment/organizational decisions remain harder and still require human expertise.

### Почему не расширять III

This is valuable material, but it belongs to evidence, operational projection, or governance. For chapter III the only needed conclusion is narrower: generated/reconstructed/validated ADR artifacts remain candidate or support artifacts until accepted by responsible process.

## 10. Contract-testing and architecture-testing tools

Проверка показала, что отдельный добор по Pact, `oasdiff`, ArchUnit, NetArchTest, dependency-cruiser, OPA etc. сейчас не нужен.

### Решение

**Отложить для XI / Handbook.**

### Причина

MADR and evolutionary architecture already support the conceptual point. Tool examples would pull chapter III into implementation catalog and weaken the central line.

## Сводная таблица решений

| Источник | Решение | Роль в III | Риск |
| --- | --- | --- | --- |
| Nygard / Cognitect | Встроить сейчас | Minimal ADR; future developer; status/consequences | Tutorial drift |
| Fowler | Встроить сейчас, lightly | Decision log; brevity; historic record | Duplicate Nygard |
| AWS ADR process | Встроить сейчас | Lifecycle, immutability, superseding, review | Process tutorial |
| MADR template | Встроить сейчас | `Confirmation` bridge | Tool/template catalog |
| Evolutionary Architecture | Встроить сейчас, one paragraph | Partial objective confirmation | New school/theme |
| GitHub CODEOWNERS | Conditional integrate | Review routing example | XII authority drift |
| 2024 LLM ADD study | Conditional integrate | LLM can assist generation; not authority | AI/ADR literature survey |
| DRAFT | Source register | Drafting support / better than prompting | Survey drift |
| Context/AgenticAKM/violation detection | Defer | XI/XII support | Pulls into validation/governance |
| Contract/testing tools | Defer | Future evidence examples | Tool catalog |

## Интеграционная формула для черновика

В главе III внешние источники должны работать так:

```text
Nygard/Fowler/AWS → ADR is decision memory with lifecycle.
MADR → ADR may include confirmation of implementation/compliance.
Evolutionary architecture → some architectural qualities can be checked by limited fitness functions.
GitHub CODEOWNERS → review routing can be one confirmation route.
LLM/ADR papers → model-generated ADR is plausible as draft/candidate, not accepted decision.
```

## Статус

Источники раскрыты, решения приняты. Для следующего прохода можно писать контур черновика без нового поиска. Главная защита: каждый внешний источник должен поддерживать одну фразу главы, not expand the chapter’s territory.
