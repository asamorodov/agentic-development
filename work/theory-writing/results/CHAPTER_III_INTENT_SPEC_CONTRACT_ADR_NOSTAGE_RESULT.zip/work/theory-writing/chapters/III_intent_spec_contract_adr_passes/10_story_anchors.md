# P10 — исторические опоры для главы III

## Принцип отбора

Истории нужны как короткие опоры, а не как замена объяснения. Глава III должна сама развести намерение, спецификацию, контракт и ADR. Исторические вставки работают только там, где показывают это различение на живой практике.

Использовать четыре истории:

1. Boris Tane — минимальный doc-first цикл перед кодом;
2. HumanLayer — harness and context budget around research/plan/implement;
3. Matt Pocock — PRD, user stories, skills and procedural memory;
4. Mike McQuaid — maintainer boundary, sandbox/worktrees and accepted responsibility.

Не добавлять новые истории, если черновик уже держится.

## 1. Boris Tane — `research.md` and `plan.md` before code

### Что взять

Boris даёт самый компактный эмпирический якорь для начала главы:

```text
Research → Plan → Annotate → Todo List → Implement → Feedback
```

Смысл для III: намерение не должно сразу становиться кодом. Оно сначала проходит через внешний артефакт, который можно прочитать и исправить до реализации.

Ключевые детали:

- `research.md` shows how agent understood the real system;
- wrong research produces wrong plan, and wrong plan can produce many wrong lines of code;
- `plan.md` is where human annotations correct assumptions, constraints and priorities;
- agent does not receive right to implement until plan is checked;
- difficult-to-reverse decisions — data model, service boundaries, public API, migrations — especially need this front-loaded discipline.

### Где поставить в главе

В начале, в разделе about intent becoming a specification surface. Boris is not ADR yet. Это ещё pre-ADR слой: переносимое понимание и план, где человек может удержать смысл before code.

### Чего не делать

Не пересказывать всю историю. Не превращать Boris в “методику главы”. Он нужен как нижняя граница: two markdown files and a prohibition on early implementation.

## 2. HumanLayer — harness around research, plan and verification

### Что взять

HumanLayer показывает, что спецификация не живёт в пустоте. Agentic work depends on harness:

```text
coding agent = AI model(s) + harness
```

Для главы III важны не все элементы harness, а три:

- context quality before next step matters more than raw context-window size;
- practical target like 40–60% context-window usage shows context is managed before collapse, not only after failure;
- research → plan → implement is preserved as a loop where plan can store phase state, remaining work, checks and questions;
- plan is not summary; it translates research into files, steps, checks and completion conditions.

### Где поставить в главе

В середине, когда глава moves from specification as document to specification as contract with environment. HumanLayer can support the line: a good spec is not only text; it is connected to context loading, tool boundaries, verification signals and stopping points.

### Чего не делать

Не разворачивать весь `harness` as chapter topic. Full harness belongs to runtime/process chapters. Here it is only a support for the claim: specification has to control what the agent sees, does and treats as complete.

## 3. Matt Pocock — PRD, user stories and procedural memory

### Что взять

Pocock gives the strongest story anchor for portable intent and procedural memory.

Relevant elements:

- PRD contains problem, proposed solution, user stories, implementation decisions, testing decisions, out-of-scope and notes for future agent;
- warning not to clear context before writing PRD if design decisions accumulated in the conversation;
- `/to-issues` turns PRD/plan/spec into vertical slices, not horizontal layers;
- issue triage reads `AGENT-BRIEF.md`, `OUT-OF-SCOPE.md`, project language and ADR;
- `.out-of-scope/*.md` captures rejected directions with decision, reason and prior requests;
- Ralph loop uses `PRD.md`, `progress.txt` and completion marker to preserve state across independent agent runs;
- `/handoff` should link to PRD, plans, ADR, issues, commits and diffs rather than duplicate their content.

### Где поставить в главе

Use in two places:

1. PRD paragraph — specification as portable carrier of intent between chat and future execution.
2. Contract paragraph — vertical slices, progress file and completion marker show how a broad intention becomes checkable units.

### Чего не делать

Do not import the whole skills library. Chapter III needs PRD/user stories/vertical slice/procedural memory, not `/tdd`, `/diagnose`, architecture review, or all Pocock skills.

## 4. Mike McQuaid — maintainer boundary and accepted responsibility

### Что взять

Mike is useful less for specification and more for boundary around accepted action.

Relevant elements:

- sandbox/worktrees make autonomous agent work safer, but do not transfer responsibility;
- local diff still has to be read and accepted by developer;
- AI code review can be extra filter, not replacement for maintainer judgment;
- Homebrew rules require author to check generated code/prose/content before asking maintainers to review;
- external AI PR should not push hidden work upward onto maintainers;
- Sandvault, worktrees, CI, human review and contribution rules are separate layers, not one magical safety mechanism.

### Где поставить в главе

Near the end, as boundary to XII: specification and contract can prepare work for acceptance, but they do not by themselves grant authority to publish or merge. This should connect to ADR status/origin distinction:

```text
agent-drafted artifact can be useful;
accepted decision remains a human/process status.
```

### Чего не делать

Do not retell Sandvault mechanics. Chapter III only needs Mike for “prepared artifact is not accepted authority”. Full sandbox/worktree practice belongs to runtime/autonomy chapters.

## Cross-story use pattern

The four stories should appear as small anchors in one continuous argument:

```text
Boris → intention is externalized before code.
HumanLayer → the externalized plan belongs to a harness and context budget.
Pocock → PRD/issues/handoff preserve intention and procedural memory across sessions.
Mike → prepared AI work still needs accepted human/process responsibility.
```

This chain fits the chapter’s own movement:

```text
intent
→ specification surface
→ checkable contract
→ decision memory / ADR
→ boundary of acceptance
```

## Suggested insertion points

### Opening section

Use Boris as first story anchor. One paragraph is enough:

> In Boris Tane’s minimal cycle, a task cannot go directly from prompt to code; it first becomes `research.md`, then `plan.md`, then annotated plan. This is the smallest visible form of specification in the corpus.

### Specification section

Use HumanLayer to show that plan quality depends on context and harness, not only on document wording.

### Contract section

Use Pocock to show PRD → vertical issues → progress/completion marker. This gives a concrete route from broad intent to checkable slices.

### ADR / acceptance section

Use Mike to close the boundary: sandboxed worktree, AI review and generated artifacts help, but acceptance remains a status granted by responsible process.

## Do-not-use list for this chapter

Do not bring in:

- full HumanLayer benchmark/harness comparison;
- full Sandvault setup;
- full Pocock skills catalog;
- Boris feedback-loop details after implementation;
- Mike’s macOS-specific directory structure;
- Homebrew merge-rate claims;
- detailed diagrams unless final publication layer asks for them.

## Статус

Исторические опоры отобраны. Они должны work as load-bearing examples, not as chapter spine. The spine remains conceptual: intent, specification, contract, ADR and accepted status.
