# P06 — карта лакун по досье для главы III

## Цель проверки

Проверка досье не должна превращать главу в подробный источник-реестр. Нужны только различения, без которых глава станет поверхностной или начнёт смешивать спецификацию, контракт, ADR, свидетельства и процесс.

## ADR dossier — обязательные доборы

ADR-досье содержит несколько деталей, которые должны попасть в главу или повлиять на её черновик.

### Nygard: минимальная форма и стиль записи

Не потерять, что классический ADR у Nygard не является бюрократическим шаблоном. Это короткая запись рядом с кодом, рассчитанная на будущего разработчика. Минимальная форма:

```text
Title
Context
Decision
Status
Consequences
```

Для главы нужны не все детали, а смысл: `Context` хранит силы и ограничения, `Decision` фиксирует выбор, `Status` говорит, действует ли решение, `Consequences` показывает новый контекст для будущей работы. Номера, расположение `doc/arch/adr-NNN.md` and one-two-page rule можно упомянуть только если нужен конкретный пример, но не делать практическую инструкцию.

### Fowler / AWS: жизненный цикл и запрет переписывать принятое прошлое

Глава должна сохранить дисциплину замены: принятый ADR не правится задним числом, а связывается с новым superseding ADR. AWS важен тем, что показывает ADR как процесс: owner, review, accepted/rejected/rework, timestamp, version, immutability of accepted records and replacement through new ADR.

Эта линия обязательна, потому что она делает ADR именно памятью решения, а не живым файлом, который агент может “улучшить” как README.

### MADR `Confirmation`

Досье подчёркивает, что `Confirmation` нельзя сжимать до “один тест”. Для главы нужно сохранить принцип:

- `Confirmation` указывает, как будет подтверждаться реализация или соблюдение решения;
- это может быть review, architectural test, contract check, `CODEOWNERS`, SLO/metric, rollout analysis or manual review;
- каждый сигнал подтверждает только свою часть решения;
- хорошая формулировка должна содержать не только `proves`, но и границы `does_not_prove`.

Подробные инструменты `ArchUnit`, `NetArchTest`, `dependency-cruiser`, `Open Policy Agent`, `oasdiff`, Pact, k6, SLO, Argo Rollouts and Flagger можно использовать как источник словаря, но не переносить списком.

### Generated/reconstructed ADR boundary

Это обязательный добор. Досье разделяет AI/ADR-исследования на несколько разных тем: генерация ADR, выбор контекста, выявление нарушений ADR, трассируемость and reconstruction. Эти темы нельзя сжимать в “LLM может писать ADR”.

Для главы нужны два правила:

1. LLM может помочь написать или восстановить ADR, но это не означает, что LLM приняла архитектурное решение.
2. `origin` and `status` must remain separate. `origin: reconstructed` or `origin: agent-drafted` does not imply `status: accepted`.

Минимальные поля для reconstructed/candidate record в теории: evidence, confidence, known gaps, review owner / review status and confirmation plan. Детальная схема может остаться в Atlas / Handbook.

### Operational projection and ADR-gate

Досье добавляет важный практический паттерн:

```text
полный ADR → разрешитель активного набора → короткая операционная проекция → контекст агента / hook → детерминированные проверки, где возможны → человеческое ревью для остального
```

Главе не нужен полный механизм resolver/gate, но нужна мысль: агенту нельзя давать весь ADR-журнал как плоский набор инструкций. Ему нужна короткая, статус-aware проекция принятого решения с обратной ссылкой, областью применения, проверкой and lifecycle metadata.

## SPDD dossier — что добавить только как мост

SPDD-досье подтверждает, что SPDD относится к формализации намерения низкой/средней строгости. Оно находится между свободным prompt and formal specification/DSL. Для главы III стоит взять только следующие доборы:

- SPDD — слой управления, а не усилитель возможностей модели;
- REASONS Canvas — контракт поглощения контекста, где агенту не разрешено самому выбирать границы смысла;
- `/spdd-api-test` and `/spdd-code-review` проверяют соответствие реализации Canvas, но не доказывают правильность исходного намерения;
- `/spdd-prompt-update` and `/spdd-sync` показывают, что спецификация нуждается в последующей поддержке.

Не переносить детальную командную поверхность, ROI, roadmap, downstream adapters and сценарии внедрения. Это материал IV.

## Spec Kit dossier — что добавить без превращения в каталог

Spec Kit-досье полезно для границы между `spec`, `plan`, `tasks` and implementation. Для III нужны только лакуны:

- человеческие подтверждения находятся не в одном месте, а на переходах между артефактами;
- `/speckit.plan` должен работать с `constitution` and Constitution Check;
- `/speckit.analyze` полезен как read-only audit consistency before implementation;
- хвост жизненного цикла: если specification/plan/tasks changed or drift, dependent artifacts must be updated.

Не переносить installation, adapters, presets, detailed workflows, agent participant roles. Они относятся к V or Handbook.

## CSDD dossier — traceability and checkpoints

CSDD-досье даёт главе важный higher-order specification слой. Обязательные доборы:

### Traceability / compliance matrix

Матрица соответствия не является декоративной таблицей. Она должна связывать:

```text
principle / CWE / control → file / line / implementation technique → test / scanner / review / evidence
```

Если есть только “это правило затронуто”, матрица фиксирует намерение, а не покрытие. Для главы III это хороший пример контракта между верхним правилом and local implementation: правило становится проверяемым только через трассируемую связь с кодом and evidence.

### Human checkpoints

CSDD требует несколько человеческих точек: утверждение Constitution, review of feature spec, plan/tasks propagation, read-only consistency analysis before implementation, merge-time matrix/evidence, exception process and amendment governance. В главе III не нужно перечислять все, но нужно показать: higher-order specification получает силу только если меняет допустимый следующий шаг.

### False confidence

CSDD особенно хорошо показывает риск ложной зрелости: `Constitution Check PASS` ничего не стоит, если expected artifacts absent, if tasks don't carry the rule, or if PR lacks evidence. Это пригодится для общего тезиса о контракте: проверяемая форма должна иметь реальные носители, а не только отметку.

## TDAD dossier — только для границы contract/evidence

TDAD-досье использовать осторожно. Для главы III оно может дать только одно различение: тесты имеют разные роли.

- В одной линии тесты задают поведение агента / спецификацию для agent definition.
- В другой линии тесты помогают регрессионному маршруту в agentic development.

Для III полезен только вывод: тест or contract can express a checkable expectation, but it does not exhaust specification and does not preserve architectural rationale. Полный TDAD-разбор belongs to V/XI.

## BMAD dossier — только если нужен процессный контраст

BMAD-досье может пригодиться только как процессный контраст: PRD / architecture / story / sprint-status show that process artifacts can act as contracts between roles and phases. Но для главы III это второстепенно. Если использовать, то только в одной фразе о том, что process contract differs from specification and ADR. Подробности BMAD belong to VIII.

## Результирующая gap map для черновика

| Лакуна | Что добавить в главу | Где использовать | Не делать |
| --- | --- | --- | --- |
| ADR lifecycle | Accepted ADR is immutable; replacement through new ADR / superseding link | Section on ADR as memory | Не писать tutorial по `adr-tools` |
| Status vs origin | generated/reconstructed is candidate until review | Candidate records section | Не утверждать, что LLM принимает решения |
| MADR `Confirmation` | plan of limited confirmation, `proves`/`does_not_prove` | Bridge to contract/evidence | Не перечислять все инструменты |
| Operational projection | short rule for agent with backlink/status/scope/check | ADR in agent context | Не делать Handbook card |
| CSDD traceability | rule → artifact → evidence | Specification/contract boundary | Не превращать в security chapter |
| Human checkpoints | artifact has authority only if it changes next permitted step | CSDD paragraph and conclusion | Не раскрывать governance fully |
| TDAD contract/evidence boundary | test is checkable expectation, not rationale | Contract paragraph | Не разворачивать TDAD |
| BMAD process contract | maybe one contrast if needed | Optional | Не вводить BMAD as method donor |

## Статус

Внутреннего материала достаточно для сильного черновика. Главный обязательный добор — аккуратно развести `status` and `origin` for ADR and show `Confirmation` as limited bridge to evidence. Без этого глава будет звучать как обычный обзор “спецификации и ADR полезны”.
