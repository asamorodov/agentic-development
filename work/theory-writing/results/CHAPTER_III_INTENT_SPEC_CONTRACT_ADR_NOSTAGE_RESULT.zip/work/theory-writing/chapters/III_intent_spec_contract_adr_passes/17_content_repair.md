# P17 — добор содержательных моментов

## Общая оценка первого черновика

Первый черновик выполняет основную задачу: читатель понимает, что specification, contract and ADR have different responsibilities. Но пять узлов имеют разную силу. Два узла уже сильные; три требуют точечного усиления.

| Узел | Статус | Что делать |
| --- | --- | --- |
| Спецификация не равна контракту | Сильный, но можно уплотнить | Добавить substitution paragraph and “next permitted action” sentence |
| Контракт не равен тесту вообще | Средний | Добавить contract/oracle warning and examples beyond test |
| ADR не равен спецификации | Сильный | Сохранить; добавить one sentence about ADR not governing current work directly |
| `Confirmation` не закрывает evidence целиком | Сильный | Keep `proves/does_not_prove`; maybe reduce examples if too many |
| Generated/reconstructed ADR remains candidate | Очень сильный | Keep central; avoid over-explaining AI papers |

## Узел 1 — спецификация не равна контракту

### Current state

Черновик хорошо говорит:

- specification is broad carrier of intent;
- contract is narrower and checkable;
- if contract is mistaken for specification, work narrows to what can be checked;
- if specification is mistaken for contract, good prose looks more authoritative than it is.

### Weakness

Не хватает ранней формулы о подменах. Сейчас distinction emerges gradually; reader sees it, but not as the chapter’s problem statement.

### Repair insertion

Add after the opening or early in section 2:

```text
Главный сбой начинается не с отсутствия документов, а с подмены их обязанностей. План начинает выглядеть как принятое решение. Зелёный тест начинает выглядеть как доказательство правильного намерения. ADR начинает работать как текущая инструкция агенту. Сгенерированная реконструкция начинает выглядеть как исторический факт. Спецификация нужна именно для того, чтобы намерение получило рабочий носитель, но этот носитель не должен автоматически получать полномочия контракта, свидетельства or принятого решения.
```

### Additional sentence

```text
Спецификация становится рабочей не в момент написания, а в момент, когда меняет следующее разрешённое действие агента.
```

## Узел 2 — контракт не равен тесту вообще

### Current state

Черновик lists many contract surfaces: acceptance criteria, API behavior, compatibility, required review, rollout gate, completion marker. Good.

### Weakness

The word “контракт” may still feel like “test/acceptance check”. Need sharper distinction: contract is a checkable expectation; test is only one possible instrument.

### Repair insertion

Add in section 3:

```text
Тест — только один способ проверить контракт. Контракт может быть поведенческим, интерфейсным, архитектурным, процедурным or владельческим. Он может требовать запуска теста, но также может требовать review, compatibility analysis, migration dry run, rollout observation, explicit exception or owner approval. Поэтому контракт нельзя сводить к тесту: тест даёт сигнал, а контракт задаёт, какой сигнал нужен и почему этот сигнал относится к спецификации.
```

### Contract/oracle warning

Add after this:

```text
Контракт должен оставаться связанным со спецификацией обратной ссылкой. Иначе агент может оптимизировать под наблюдаемый сигнал: пройти тест, сохранить форму API, получить галочку ревью, но оставить исходное намерение за пределами результата.
```

## Узел 3 — ADR не равен спецификации

### Current state

This is mostly strong. The draft states:

```text
Specification says how to conduct change.
ADR says why significant decision was made and what status it has.
```

### Weakness

Need one sentence preventing ADR from becoming current instruction file.

### Repair insertion

In ADR section or operational projection section:

```text
ADR может ограничивать будущую работу, но он не является планом текущей задачи. Чтобы стать правилом для агента, accepted ADR должен пройти через короткую рабочую проекцию with backlink, status, scope and review/check expectations.
```

This also prepares projection discipline.

## Узел 4 — `Confirmation` не закрывает evidence целиком

### Current state

Strong. The draft has:

- `Confirmation` from MADR;
- review/test/CODEOWNERS/metrics as examples;
- fitness functions;
- `proves / does_not_prove`.

### Weakness

Maybe too many examples in one section. But content is not weak; repair should sharpen final boundary:

```text
`Confirmation` не хранит свидетельство и не заменяет будущую проверку. Оно заранее описывает, где команда будет искать сигнал and what that signal can mean.
```

Add this near end of section 4.

## Узел 5 — generated/reconstructed ADR remains candidate

### Current state

Very strong. It has `origin` vs `status`, candidate fields, warning about convincing format.

### Weakness

External papers might distract. Keep the section but maybe reduce the literature sentence.

### Repair rule

Do not add more papers. Keep one general sentence:

```text
Исследования LLM-assisted ADR show that drafting and generation are plausible, but this supports only drafting capability, not decision authority.
```

Then return immediately to origin/status.

## Additional bridge from C1

Add near the end, before Mike or after Mike:

```text
После начала исполнения появляется ещё один слой, который эта глава только обозначает: состояние работы. Спецификация говорит, что должно быть проведено; контракт говорит, что проверить; ADR говорит, почему решение принято. Но ни один из них сам по себе не хранит текущего владельца, блокировку, handoff, partially attached evidence or safe continuation point. Для этого нужен отдельный persistent work state.
```

This prevents overclaiming that spec/contract/ADR solve continuation.

## Second-draft repair order

1. Add substitution paragraph near opening.
2. Rewrite method paragraph around responsibility, not method names.
3. Add next-permitted-action sentence.
4. Add contract-not-test paragraph.
5. Add contract/oracle backlink warning.
6. Add ADR projection/backlink/status/scope sentence.
7. Add `Confirmation` boundary sentence.
8. Add C1 work-state bridge.
9. Lightly tighten generated ADR literature sentence.

## Status

No deep content gap remains. The next draft should be a targeted repair pass over `13_first_synthetic_draft.md`, not a new synthetic rewrite from zero.
