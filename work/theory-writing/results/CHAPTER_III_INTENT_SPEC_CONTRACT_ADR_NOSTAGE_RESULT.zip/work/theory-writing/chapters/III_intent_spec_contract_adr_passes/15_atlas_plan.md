# P15 — интеграция Атласа в главу III

## Главный принцип

Atlas material must enter the chapter through responsibilities, not through method names. If a paragraph starts to sound like:

```text
SPDD делает..., Spec Kit делает..., CSDD делает..., ADR делает...
```

it should be rewritten as:

```text
Носитель намерения должен...
Поверхность планирования должна...
Контракт должен...
Память решения должна...
Confirmation should...
Higher-order rule should...
```

Method names can appear only as concrete anchors after the responsibility has been stated.

## ADR — память решения and status discipline

### Role in chapter

ADR holds the responsibility of decision memory:

- why a significant choice was made;
- what context/forces surrounded it;
- what consequences it creates;
- what status it has;
- how it is replaced when context changes.

### How to integrate

Use ADR in sections 5–7 only. It should not appear as a generic document example in specification section.

Recommended wording:

```text
ADR не конкурирует со спецификацией. Спецификация управляет текущим изменением; ADR сохраняет причину and status of a significant decision, so future work does not reconstruct it from code.
```

### Guardrails

- Do not explain all ADR templates.
- Do not turn AWS process into tutorial.
- Do not add ADR tooling survey.
- Keep `Confirmation` separate from full evidence theory.

## SPDD — носитель намерения as delivery artifact

### Role in chapter

SPDD supports the responsibility of making intent a first-class artifact. It should appear mainly in the transition to IV and lightly in specification section.

### How to integrate

Use SPDD as a preview of the next chapter:

- structured prompt as reviewed artifact;
- REASONS Canvas as structured carrier of requirements, entities, approach, structure, operations, norms and safeguards;
- generation, review and sync as lifecycle of the specification.

Recommended wording:

```text
SPDD интересен здесь не как ещё один шаблон, а как пример того, что промпт может стать сопровождаемым артефактом поставки: он управляет генерацией, участвует в проверке and later must be synchronized with code.
```

### Guardrails

- Do not explain `/spdd-story`, `/spdd-analysis`, `/spdd-generate`, `/spdd-api-test`, `/spdd-code-review`, `/spdd-sync` here.
- Do not make SPDD the hidden center of III. Chapter IV owns that depth.

## Spec Kit — artifact transitions and next allowed action

### Role in chapter

Spec Kit supports the responsibility of typed transitions:

```text
specification → plan → tasks → analyze/check → implementation
```

The chapter should use it only to show that each artifact changes what the agent may do next.

### How to integrate

Use one short mention in specification section:

```text
В Spec Kit спецификация не остаётся одним файлом: `spec.md`, `plan.md` and `tasks.md` carry different obligations. The important point for this chapter is not the command sequence, but that each transition changes what the agent is allowed to do.
```

### Guardrails

- Do not enumerate slash commands.
- Do not explain workflows, templates, presets or integrations.
- Do not compare Spec Kit to SPDD in main text.

## CSDD — higher-order rule as working constraint

### Role in chapter

CSDD supports the responsibility of constitution/policy above local feature intent. It helps show that a specification can carry not only local product desire, but also durable constraints that must reach downstream artifacts.

### How to integrate

Use one sentence in specification section or contract section:

```text
В CSDD верхнее правило становится рабочим только тогда, когда оно reaches files, tasks, reviews and evidence; otherwise the Constitution remains a declaration rather than a control surface.
```

Better Russian version for draft:

```text
В CSDD верхнее правило работает только тогда, когда проходит в конкретные файлы, задачи, ревью and свидетельства; иначе `Constitution Check PASS` остаётся декларацией.
```

### Guardrails

- Do not include traceability matrix figure.
- Do not expand security/compliance topic.
- Do not explain governance beyond next-action constraint.

## TDAD and BMAD

### Decision

Do not integrate directly in chapter III unless later repair finds a gap.

TDAD can support the contract/evidence boundary, but the first draft already explains this through `Confirmation` and fitness functions. BMAD belongs to process/role layer and is not needed.

## Atlas-backed rewrite of method-sounding paragraph

Current draft section contains a paragraph:

```text
В SPDD ... В Spec Kit ... В Constitutional SDD ...
```

This is acceptable in first draft but should be rewritten by responsibility:

```text
Иногда носитель намерения остаётся на уровне плана. Иногда он становится структурированным промптом, где требования, сущности, подход, порядок действий, нормы and safeguards separated before generation. Иногда он проходит через typed handoffs: product specification, technical plan and executable tasks. Иногда над локальной задачей стоит constitution-level rule, and the local specification is valid only if that rule reaches downstream artifacts. Method names differ, but the obligation is the same: specification becomes real when it changes what the agent may do next.
```

Then method names can appear in parentheses or footnote-like clauses:

```text
SPDD, Spec Kit and CSDD show three versions of this obligation.
```

## Atlas-backed insertion points

### Section 2 — Specification

Insert responsibility-based paragraph about structured prompt / typed handoffs / constitution. Keep method names secondary.

### Section 4 — Confirmation

Use MADR and evolutionary architecture only. Do not bring CSDD traceability here unless needed.

### Section 5 — ADR

Use ADR Atlas material strongly: status, immutable accepted record, superseding. This is already good.

### Section 7 — Generated ADR

If using AI/ADR research, keep it as support for candidate status. Do not add AgenticAKM mechanics.

### Section 9 — SPDD transition

Strengthen SPDD as lifecycle artifact and hand off to next chapter.

## Terms to keep stable

| Responsibility | Preferred wording |
| --- | --- |
| Intent carrier | носитель намерения |
| Specification surface | поверхность делегированного смысла / рабочая поверхность спецификации |
| Planning surface | поверхность планирования |
| Checkable contract | проверяемый контракт / проверяемое ожидание |
| Decision memory | память решения |
| Confirmation | `Confirmation` / ограниченный план подтверждения |
| Higher-order rule | верхнее правило / constitution-level rule |
| Candidate ADR | candidate record / ADR-кандидат |
| Status boundary | происхождение не равно статусу |

## Status

Atlas integration should not add new bulk. It should reshape a few method-name paragraphs around responsibilities. ADR remains central in chapter III; SPDD is mostly a bridge to IV; Spec Kit and CSDD appear as small supporting examples of artifact transitions and higher-order constraint.
