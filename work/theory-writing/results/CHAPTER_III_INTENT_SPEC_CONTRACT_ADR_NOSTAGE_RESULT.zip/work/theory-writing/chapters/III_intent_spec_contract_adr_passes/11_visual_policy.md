# P11 — визуальная политика главы III

## Общая позиция

Глава III не должна выглядеть как обзор шаблонов. Визуальный слой нужен только там, где он помогает читателю удержать различие обязанностей:

```text
intent → specification surface → checkable contract → ADR / decision memory → accepted status
```

Поэтому базовое решение: **0–1 обязательная фигура, максимум 2**, если при сборке сайта окажется, что тексту нужна дополнительная опора.

В текущем пакете локальные image assets не приложены. Истории содержат ссылки на локальные изображения полного сайта, но сами файлы не входят в пакет. Поэтому текущий рабочий выход фиксирует policy and candidates, not actual asset placement.

## Обязательный кандидат — авторская схема перехода обязанностей

### Решение

**Использовать одну авторскую схему, если глава после черновика получается плотной.**

### Назначение

Схема должна показать не методы, а смену носителя и статуса:

```text
Намерение
  ↓ externalize
Спецификация / PRD / plan
  ↓ narrow
Проверяемый контракт / acceptance surface / Confirmation
  ↓ record
ADR / decision memory
  ↓ accept or supersede
Принятый статус / новая замещающая запись
```

Второй вариант той же схемы может быть двухслойным:

```text
What must be true?     → specification
How can we check part? → contract / Confirmation
Why this decision?     → ADR
Who accepted it?       → status / owner / review
```

### Почему это полезно

Без такой схемы читатель может смешать:

- спецификацию and тест;
- ADR and живую инструкцию агенту;
- generated ADR and accepted decision;
- `Confirmation` and proof of full correctness.

### Ограничение

Схема должна быть simple explanatory diagram, not source figure. Не вставлять логотипы методов, slash-command chains or screenshots.

## Опциональный кандидат — ADR lifecycle mini-diagram

### Решение

**Использовать только если черновик плохо удерживает status/origin boundary.**

### Минимальная форма

```text
agent-drafted / reconstructed
        ↓ review
proposed ADR
        ↓ accepted by responsible process
accepted ADR
        ↓ new insight / changed context
superseded by new ADR
```

Add side note:

```text
origin ≠ status
```

### Почему может быть нужен

Это самая опасная точка главы. Агент может написать убедительный ADR, но это не делает его принятой памятью проекта. Mini-diagram can protect the distinction better than a paragraph.

### Ограничение

Не делать полный AWS process diagram. Не переносить review meetings, stakeholders, versioning and timestamps as visual bureaucracy. Нужна только status logic.

## Кандидаты, которые не использовать в основной главе

### SPDD Canvas / workflow

**Не использовать в III.**

SPDD уже имеет самостоятельную глубокую главу. Если вставить REASONS Canvas here, глава начнёт казаться введением в SPDD, а не общей главой about intent/spec/contract/ADR. Допустима одна текстовая ссылка на SPDD как пример structured intent, but no figure.

### CSDD traceability matrix

**Не использовать, кроме крайней необходимости.**

Traceability matrix visually strong, but it pulls the reader toward security/compliance and evidence. For III it is enough to explain that higher-order rules become contract only through traceable carriers. Full matrix belongs to CSDD / evidence chapter.

### Spec Kit cycle

**Не использовать.**

Spec Kit workflow is valuable for a method-specific chapter, but in III it would push the text into command-chain catalog: `specify → clarify → plan → tasks → analyze → implement`. The chapter needs the idea of artifact transitions, not the full product cycle.

### Screenshots of templates

**Не использовать.**

Screenshots of ADR templates, PRD templates or skills templates would add visual noise. The chapter should not teach template completion.

## Figure captions policy

If the conceptual scheme is used, caption should explain the distinction, not the method:

> Схема показывает не последовательность инструментов, а смену обязанностей: спецификация формулирует намерение, контракт делает его частично проверяемым, ADR сохраняет решение and status separates draft from accepted memory.

Avoid captions like:

- “workflow of specification methods”;
- “ADR process overview”;
- “SPDD/Spec Kit/CSDD comparison”.

## Publication placement

Preferred placement:

1. Main conceptual diagram after first section, once all four terms are introduced.
2. ADR lifecycle mini-diagram only near candidate/generated ADR paragraph, if paragraph otherwise becomes too abstract.

Do not place figures before the chapter has named the problem. The visual should clarify already stated distinctions, not replace exposition.

## Статус

Visual policy fixed: **one conceptual diagram is allowed, second ADR-status diagram only if needed**. Method-specific figures are rejected for this chapter because they would shift the reader from conceptual distinction to method catalog.
