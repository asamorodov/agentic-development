# P12 — читательский ход и план главы III

## Главный ход главы

Глава начинается после предыдущего вопроса о сессии агента: даже если агент хорошо понял задачу в текущем разговоре, остаётся более трудный вопрос — где это намерение живёт после разговора, после сжатия контекста, после смены агента, после появления кода and after the first decision starts affecting future work.

Ответ главы:

```text
намерение должно получить носитель;
носитель должен стать спецификацией;
спецификация должна сузиться в проверяемые контракты;
важное решение должно сохраниться как ADR;
status/review must distinguish draft from accepted memory.
```

Глава не должна обещать, что эти формы доказывают правильность изменения. Они только меняют место, где можно спорить, проверять, принимать and заменять.

## Reader path

### 1. После агентской сессии остаётся проблема носителя

Начать не с определения спецификации, а с сбоя:

- prompt can contain intent, but prompt disappears into conversation;
- chat summary compresses and distorts;
- implementation diff shows what changed, but not why this change was chosen;
- tests can catch some behavior, but not the reasoning boundary;
- future agent can reconstruct plausible intent, but plausible reconstruction is not the same as accepted intent.

Use Boris as short opening anchor: `research.md` and `plan.md` show the minimal move from chat to external document. The point is not Boris’s whole workflow, but the moment when intention leaves the conversation and becomes inspectable before code.

### 2. Specification: not “more prompt”, but a surface of delegated meaning

Define specification by responsibility:

- it says what change is being attempted;
- what is in scope and out of scope;
- which constraints, invariants and non-goals matter;
- what the agent should read or preserve;
- what would count as acceptable direction before implementation;
- what must survive across sessions.

Important distinction:

```text
Intent is what the human wants to change.
Specification is the external surface through which that intent can govern work.
```

Bring in HumanLayer briefly: a plan is part of harness/context management. A specification is weak if it does not affect what the agent sees, does, checks and treats as finished.

### 3. Specification becomes operational only through narrowing

Move from general spec to operational contract. A specification can be broad; a contract is narrower and checkable.

Examples of contract surfaces:

- acceptance criteria;
- API behavior;
- compatibility boundary;
- vertical slice / tracer bullet;
- “do not touch” or “watch-only” zones;
- required review route;
- completion marker;
- rollback or migration condition;
- `Confirmation` in an ADR.

Use Matt Pocock here: PRD can preserve intent, but `/to-issues`, vertical slices, `progress.txt` and completion marker show how intent becomes smaller units the harness can execute and inspect.

Important sentence for draft:

> Контракт не заменяет спецификацию. Он выделяет часть спецификации, которую можно проверить, передать или заблокировать.

### 4. `Confirmation`: bridge to evidence, not evidence chapter

Introduce MADR `Confirmation` as an ADR field where implementation/compliance can be confirmed.

Then immediately narrow:

- a test confirms only tested behavior;
- a structural rule confirms only the structural property it observes;
- `CODEOWNERS` route confirms that a named owner reviewed, not that decision is intrinsically correct;
- metric/rollout gate confirms an observed runtime property, not all future behavior.

Use evolutionary architecture / fitness functions as support: some architectural characteristics can have objective integrity assessments. But do not expand into architecture testing.

Draft formula:

```text
Confirmation should contain both proves and does_not_prove.
```

This leads naturally toward chapter XI, but the current chapter must stop before full evidence theory.

### 5. ADR: decision memory, not current instruction file

After specification/contract, introduce ADR by its separate responsibility:

```text
Specification says what work should be done.
Contract says how part of it can be checked.
ADR says why a significant choice was made and what status that choice has.
```

Use Nygard/Fowler/AWS:

- context, decision, status, consequences;
- decision log as historic record;
- accepted ADR becomes immutable;
- later change is a new ADR that supersedes previous decision.

Show why this matters for agents:

- if the agent reads an old ADR as live instruction without status, it may preserve a superseded decision;
- if the agent rewrites an accepted ADR to match current code, it destroys decision memory;
- if generated/reconstructed ADR is accepted silently, model reconstruction becomes fake authority.

### 6. Design Decision Gate / operational projection

Introduce only as pattern, not tool:

```text
accepted ADR
→ active decision set
→ short operational projection for agent
→ deterministic checks where possible
→ human review where judgment is required
```

This is the bridge between ADR and agent context. It prevents two opposite failures:

1. dumping the whole ADR log into context as flat instruction;
2. letting current agent ignore decision memory completely.

Keep Design Decision Gate as a named pattern only if text needs a handle. Do not make it a new chapter object.

### 7. Generated/reconstructed ADR: origin is not status

This is the chapter’s strongest boundary.

Write as distinction:

```text
origin: agent-drafted / reconstructed / imported / human-written
status: proposed / accepted / rejected / superseded
```

These fields must not collapse. A model can draft ADR, summarize scattered decision traces, reconstruct likely rationale or detect possible violation. But this only affects origin/provenance and confidence. Accepted status still requires responsible process.

Minimum candidate fields if shown in text:

- origin;
- evidence used;
- confidence;
- known gaps;
- review owner / review status;
- confirmation plan.

Use one AI/ADR paper as support only if needed. Main source is the conceptual distinction.

### 8. Boundary to authority and maintainer responsibility

Use Mike McQuaid near the end:

- sandbox, worktree, AI review and PR automation can prepare work;
- human maintainer still must not pass unreviewed AI work upward;
- generated artifacts are useful only if accepted by responsible boundary.

This prepares chapter XII without turning III into governance.

Draft bridge:

> Спецификация and ADR can make a decision visible to the agent, but they do not by themselves grant the agent the right to complete the lifecycle.

### 9. Closing transition to IV

Close by stating that chapter III has only defined the general responsibilities. Chapter IV will take one deep case — SPDD — and show what happens when specification becomes not a loose plan but a full lifecycle artifact: structured prompt, REASONS Canvas, generation, API test/review, prompt update and sync.

Transition sentence:

> Если эта глава разводит роли спецификации, контракта and ADR, следующая показывает, что происходит, когда спецификация становится самостоятельной дисциплиной разработки, а не подготовительной заметкой перед кодом.

## Proposed section structure

```text
III. Намерение, спецификация, контракт и ADR

1. Где живёт намерение после сессии
2. Спецификация как поверхность делегированного смысла
3. Контракт: проверяемая часть спецификации
4. Confirmation: как решение получает ограниченный план проверки
5. ADR: память решения с состоянием, а не живая инструкция
6. От ADR к контексту агента: operational projection
7. Сгенерированная ADR: происхождение не равно статусу
8. Граница принятия: подготовленное агентом не равно принятое проектом
9. Переход к SPDD как глубокому случаю спецификации
```

## Load-bearing contrasts to preserve

| Distinction | Why it matters |
| --- | --- |
| Intent vs specification | Human desire must become inspectable carrier before delegation |
| Specification vs contract | Broad meaning differs from checkable promise |
| Contract vs evidence | Contract says what should be checked; evidence is later signal |
| ADR vs README/instruction | Decision memory should not be silently rewritten |
| Origin vs status | Generated/reconstructed record is not accepted record |
| Review routing vs authority | CODEOWNERS/review can route responsibility but not prove correctness |
| Prepared work vs accepted work | Agent can produce artifact; process grants acceptance |

## Tone and style for drafting

- Start from concrete failure, not abstract taxonomy.
- Avoid method-catalog transitions like “another example is…”.
- Use examples as anchors inside the argument.
- Do not overuse slash commands.
- Keep SPDD, Spec Kit, CSDD and TDAD in supporting roles.
- Avoid final claims like “this solves specification”; instead say what each artifact can and cannot preserve.

## Статус

Reader path fixed. The chapter now has a continuous argument from post-session intent to specification, contract, `Confirmation`, ADR lifecycle, generated-record boundary and transition to SPDD.
