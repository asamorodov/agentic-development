# P16 — интеграция внешних источников и досье

## Цель прохода

Проверить, какие внешние источники and dossier details should actually enter the next draft. Критерий строгий: источник нужен только если усиливает различение между specification, contract, ADR and decision authority.

## What must be integrated in next draft

### 1. Artifact substitutions

Source support: internal A2; external sources not needed.

Next draft should include one explicit paragraph about substitutions:

- plan that looks like accepted decision;
- green check that looks like architectural explanation;
- ADR that acts as current instruction;
- generated/reconstructed ADR that looks accepted;
- review routing that looks like risk acceptance.

This paragraph is theory-driven and should not be sourced to a single external document.

### 2. ADR minimal form and lifecycle

Sources:

- Nygard / Cognitect — minimal ADR form and future-developer framing;
- Fowler — ADR as short decision-log record;
- AWS — lifecycle, review, accepted immutability and superseding.

Integrate as already done, but with two small refinements:

- Mention Nygard first for `Context / Decision / Status / Consequences`.
- Use AWS for “accepted ADR becomes immutable; changed decision needs new superseding ADR”.

Do not add more ADR history or tooling.

### 3. `Confirmation` as partial evidence plan

Sources:

- MADR template for `Confirmation` field;
- evolutionary architecture / fitness functions for partial architectural checks.

Integrate as one sustained paragraph, not a tool list. Required language:

```text
Confirmation asks how implementation/compliance will be confirmed, but each signal confirms only the property it can observe.
```

Add the pair:

```text
proves / does_not_prove
```

No need to cite Pact, ArchUnit, `oasdiff`, OPA or other tools unless draft needs one concrete example. Even then, examples should stay parenthetical.

### 4. Review routing vs authority

Source:

- GitHub CODEOWNERS docs only if `CODEOWNERS` remains in main text.

Current draft uses `CODEOWNERS` in the `Confirmation` section. This is acceptable, but only as review routing:

```text
CODEOWNERS can route review to named owners; it does not prove architectural correctness and does not itself accept risk.
```

This source should not open governance discussion. The authority discussion belongs to XII.

### 5. Generated/reconstructed ADR as candidate

Sources:

- one LLM/ADR source is enough if external support is needed;
- likely use the 2024 exploratory study or DRAFT, not both;
- keep AgenticAKM / violation-detection papers for source register unless later chapter needs operational validation.

Required distinction:

```text
origin is provenance; status is project authority.
```

Fields to mention only if needed:

- evidence used;
- gaps;
- confidence;
- review owner;
- review status;
- confirmation plan.

Do not turn into AI/ADR literature review.

## What should be deferred to XI

### Evidence and testing toolchain

Defer:

- Pact / `can-i-deploy`;
- `oasdiff`;
- ArchUnit / NetArchTest / dependency-cruiser as detailed tools;
- SLO/rollout/observability examples;
- LLM violation detection as validation method.

Reason: these belong to evidence chapter. In III they would inflate `Confirmation` beyond its role.

### PWG / work-state continuation

Defer detailed Beads/Gas Town/PWG mechanics:

- ownership;
- blocking;
- gates;
- handoff;
- `bd ready`, `bd gate`, `bd prime`;
- multi-agent coordination.

In III only one bridge sentence is needed: after execution begins, work-state persistence is separate from specification/contract/ADR.

## What should be deferred to XII

### Governance and authority

Defer:

- full `CODEOWNERS` governance;
- branch protection policy details;
- open-source AI contribution policy;
- maintainer workload ethics;
- risk acceptance process.

In III use Mike McQuaid only to state boundary: prepared AI work is not accepted project work until responsible process accepts it.

## What should be kept as internal register only

- AgenticAKM details and code mechanics.
- Design Decision Gate as tool/system, beyond simple pattern.
- ADR Sync / Mneme / ADR compiler-like mechanisms.
- Detailed Spec Kit workflow docs.
- CSDD traceability matrix details.
- BMAD/GSD process framework material.

These may be useful later, but not for the next draft of this chapter.

## Next-draft insertion plan

1. **Opening or section 2:** artifact-substitution paragraph.
2. **Specification section:** rewrite method paragraph around responsibility, with SPDD/Spec Kit/CSDD as secondary examples.
3. **Contract section:** add contract/oracle warning.
4. **Confirmation section:** tighten around MADR + fitness functions + `proves/does_not_prove`.
5. **ADR section:** add derivative/projection discipline with backlink/status/scope.
6. **Generated ADR section:** keep only one external AI/ADR source if needed.
7. **Closing:** add PWG bridge and stronger SPDD transition.

## Source load limit for main chapter

Main draft should use approximately this source set:

- Nygard/Cognitect;
- Fowler;
- AWS ADR process or best practices;
- MADR template;
- evolutionary architecture fitness function;
- GitHub CODEOWNERS only if mentioned;
- one AI/ADR paper only if generated-record paragraph needs it.

This is enough. More sources would make the chapter look like a literature review.

## Status

External/dossier integration is bounded. The next pass should improve the draft through targeted insertion and tightening, not by adding new research or method coverage.
