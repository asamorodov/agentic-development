# P18 — границы с соседними главами

## Overall boundary

Chapter III is a definitions-and-responsibilities chapter. It prepares neighboring chapters by giving them clean distinctions:

```text
intent → specification → contract → Confirmation → ADR/status → accepted responsibility
```

It must not become the place where those later chapters are actually written.

## Boundary with IV — SPDD deep case

### Risk

Chapter III can accidentally take over IV if it explains REASONS Canvas, OpenSPDD commands, API tests, code review, prompt update and sync in detail.

### Current draft status

Mostly safe. It mentions SPDD briefly and transitions to IV. The final transition includes several SPDD lifecycle elements, but not too much.

### Rule for next draft

In III, SPDD should serve one purpose only:

```text
SPDD previews what happens when specification becomes a lifecycle artifact.
```

Allowed:

- structured prompt as carrier of intent;
- REASONS Canvas as named example;
- prompt as delivery artifact;
- sync after code as future chapter hook.

Not allowed:

- command catalog;
- billing example;
- SPDD adoption path;
- detailed OpenSPDD mechanics;
- deep comparison with Spec Kit/Kiro/TDAD/CSDD.

## Boundary with V — neighboring specification profiles

### Risk

Chapter III can become a taxonomy of specification approaches: SPDD vs Spec Kit vs CSDD vs TDAD vs Kiro.

### Current draft status

First draft has one method-list paragraph in section 2. It should be rewritten around responsibility, as P15 noted.

### Rule for next draft

No paragraph should be organized as a method-by-method survey. Use responsibilities instead:

- structured carrier of intent;
- typed artifact transitions;
- higher-order rule that constrains local work;
- tests/checks as one possible contract surface.

Method names may appear after the responsibility, not before it.

Allowed:

```text
SPDD, Spec Kit and CSDD show different ways for specification to change the next permitted action.
```

Not allowed:

```text
SPDD does X; Spec Kit does Y; CSDD does Z; TDAD does W.
```

## Boundary with XI — evidence and verification

### Risk

`Confirmation`, fitness functions, tests, `CODEOWNERS`, metrics and rollout gates can pull the chapter into a full evidence taxonomy.

### Current draft status

Safe but close to the line. Section 4 has many examples, but it returns to the point: confirmation is partial and future-oriented.

### Rule for next draft

III should answer:

```text
What kind of future signal does this decision/contract require?
```

XI should answer:

```text
What counts as evidence, how is it collected, attached, trusted, compared and audited?
```

Allowed in III:

- `Confirmation` field;
- `proves / does_not_prove`;
- one fitness-function explanation;
- one review-routing example if needed.

Not allowed:

- Pact/contract-testing survey;
- test oracle theory;
- CI/benchmark taxonomy;
- traceability-to-evidence chapter;
- LLM validation/violation detection discussion.

## Boundary with XII — authority, governance and right to complete

### Risk

Mike, `CODEOWNERS`, branch protection and accepted ADR can drag the chapter into governance.

### Current draft status

Mostly safe. Mike is used to say prepared work is not accepted work. `CODEOWNERS` is used as confirmation routing, not authority theory.

### Rule for next draft

III should say:

```text
Prepared artifact and accepted artifact are different statuses.
```

XII should say:

```text
Who is allowed to accept risk, merge work, close lifecycle, override rules and carry social responsibility?
```

Allowed in III:

- review routing as possible confirmation route;
- accepted ADR vs proposed ADR;
- prepared AI work vs accepted project work;
- Mike as one-paragraph boundary.

Not allowed:

- branch protection tutorial;
- open-source AI contribution policy analysis;
- maintainer ethics as full section;
- risk acceptance governance;
- CODEOWNERS as organizational theory.

## Boundary with PWG / working-state chapter

### Risk

Once chapter explains continuation after session, it may try to define persistent work graph.

### Current draft status

First draft mentions `progress.txt` and completion markers through Pocock, but does not build PWG. It needs one bridge sentence, not a full model.

### Rule for next draft

III should say:

```text
After execution begins, work-state persistence is a separate layer.
```

Do not explain:

- owners;
- dependencies;
- gates;
- handoff state;
- `bd ready` / `bd gate` / `bd prime`;
- multi-agent coordination.

## Boundary with Atlas / Handbook

### Risk

Operational projection, ADR gates and candidate fields can become practical fieldbook cards.

### Current draft status

Safe. It gives the pattern but not implementation.

### Rule for next draft

Keep only conceptual pattern:

```text
accepted ADR → active decision set → short projection → checks/review
```

Do not include YAML, schemas, gate implementation, command examples or resolver mechanics.

## Section-by-section boundary verdict

| Draft section | Boundary verdict | Repair needed |
| --- | --- | --- |
| 1. Где живёт намерение | Safe | Add artifact-substitution paragraph without pulling later chapters |
| 2. Спецификация | Close to V | Rewrite method list around responsibilities |
| 3. Контракт | Safe but needs test distinction | Add contract-not-test; no evidence taxonomy |
| 4. Confirmation | Close to XI | Keep `proves/does_not_prove`; avoid tool list |
| 5. ADR | Safe | No extra ADR tooling |
| 6. Operational projection | Close to Handbook | Emphasize derivative status; no implementation |
| 7. Generated ADR | Safe if literature stays short | Use one source only |
| 8. Acceptance | Close to XII | Keep Mike short |
| 9. SPDD transition | Safe if concise | Strengthen without deep SPDD detail |

## Status

Neighbor boundaries are under control. The next revision should deepen a few distinctions without opening IV, V, XI or XII. The most important repair is stylistic/structural: move method names behind responsibilities so the chapter remains conceptual rather than atlas-like.
