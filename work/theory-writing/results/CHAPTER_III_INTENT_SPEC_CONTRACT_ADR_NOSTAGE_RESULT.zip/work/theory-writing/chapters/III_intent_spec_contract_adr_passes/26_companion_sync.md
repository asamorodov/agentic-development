# P26 — синхронизация сопутствующих файлов

## Назначение

Этот файл синхронизирует сопутствующие карты после текущей редакции главы `25_entry_structure_sequence.md`. Он не заменяет основной текст и не прячет факты, без которых глава непонятна. Основной текст уже должен содержать все load-bearing distinctions; здесь остаются карты происхождения, использования и открытых границ.

## 1. Реестр источников

### Источники, встроенные в основной текст

| Источник | Где используется | Роль |
| --- | --- | --- |
| Michael Nygard, “Documenting Architecture Decisions” | Раздел 5 | Минимальная форма ADR: `Context`, `Decision`, `Status`, `Consequences`; разговор с будущим разработчиком. |
| Martin Fowler, “Architecture Decision Record” | Раздел 5 | ADR как короткая запись в decision log. |
| AWS Prescriptive Guidance — ADR process | Раздел 5 | Lifecycle, immutable accepted ADR, superseding through new ADR, `Superseded` status. |
| MADR template | Раздел 4 | `Confirmation` as explicit place for confirming implementation/compliance. |
| Evolutionary architecture / fitness function | Раздел 4 | Partial objective assessment of architectural characteristic. |
| GitHub CODEOWNERS docs | Раздел 4 | Review routing. |
| GitHub branch protection docs | Раздел 4 | Required code-owner review as merge gate. |
| Dhar et al. 2024 LLM/ADD paper | Раздел 7 | LLM can help generate/draft design-decision text, but not authority. |

### Источники в резерве

| Источник | Почему не встроен сейчас |
| --- | --- |
| DRAFT-ing Architectural Design Decisions using LLMs | Поддерживает drafting, but one AI/ADR source is enough. |
| Context Matters / AgenticAKM / violation detection papers | Тянут главу в generation/validation literature; лучше для XI/XII/Atlas. |
| Pact / `oasdiff` / ArchUnit / NetArchTest / dependency-cruiser | Инструментальные примеры evidence layer; для XI or Handbook. |
| Detailed AWS best practices | Process detail not needed after AWS ADR process link. |

## 2. Карта использования фрагментов

| Фрагмент | Использование в главе | Что не переносилось |
| --- | --- | --- |
| A2 — specification/ADR/contract | Главная матрица различений: specification vs contract, ADR status, `Confirmation`, origin vs status. | Полные синтетические фигуры and technical cards. |
| A3 — specification methodologies | Responsibility framing: specification changes next permitted action; protected profiles without catalog. | Full comparison of SPDD/Spec Kit/CSDD/TDAD. |
| B1 — SPDD contribution | Final transition: specification as delivery artifact, generation/review/sync lifecycle. | OpenSPDD command details and SPDD examples. |
| C1 — specification → PWG | Bridge to working state: spec/contract/ADR do not store owner/block/handoff/evidence state. | Beads/Gas Town mechanics and PWG model. |

## 3. Карта использования Атласа

| Atlas article | How used | Boundary |
| --- | --- | --- |
| ADR article | Status discipline, accepted/superseded, decision memory, `Confirmation`. | No ADR tooling/tutorial. |
| SPDD article | Bridge to IV; specification as lifecycle artifact. | No deep SPDD in III. |
| Spec Kit article | `spec.md` → `plan.md` → `tasks.md` as typed transitions. | No command chain or workflow catalog. |
| CSDD article | `Constitution` must become traceable; `Constitution Check PASS` can be decorative. | No security/governance chapter. |
| TDAD comparative | Only background for contract/evidence distinction. | Not named in main text. |
| BMAD | Not used. | Process/role layer not needed here. |

## 4. Лакуны досье — статус

| Лакуна | Status |
| --- | --- |
| ADR accepted/superseded lifecycle | Closed in section 5 with AWS and Nygard/Fowler. |
| `Confirmation` partiality | Closed in section 4 with MADR and fitness function. |
| CODEOWNERS boundary | Closed as review routing only. |
| Generated/reconstructed ADR candidate | Closed in section 7 with origin/status distinction. |
| Operational projection | Closed as conceptual pattern in section 6. |
| PWG continuation state | Only bridged, intentionally deferred. |

## 5. Журнал внешнего поиска

External search found enough sources; no further search is needed for this chapter unless a later editor adds new claims.

Search outcome:

- ADR primary sources are sufficient.
- `Confirmation` source is sufficient through MADR template.
- Fitness function source is sufficient for partial architectural checks.
- GitHub docs are sufficient for `CODEOWNERS` review routing.
- AI/ADR research should stay minimal.

## 6. Исторические опоры

| Story | Current use | Status |
| --- | --- | --- |
| Boris Tane | Opening example of `research.md` / `plan.md` before code. | Good. Does not dominate. |
| HumanLayer | Harness/context support for specification as working surface. | Good. No full harness chapter. |
| Matt Pocock | PRD, vertical slices, `progress.txt`, completion marker. | Good. Some English terms remain exact/source-native. |
| Mike McQuaid | Prepared AI work vs accepted project work. | Good. No Sandvault tutorial. |

## 7. Кандидаты на фигуры

Current decision: no mandatory figure in the chapter text yet.

Allowed future figure:

```text
intent → specification → contract → Confirmation → ADR/status → accepted responsibility
```

Optional future figure only if needed:

```text
origin ≠ status
agent-drafted / reconstructed → proposed → accepted / rejected / superseded
```

Rejected for this chapter:

- SPDD Canvas figure;
- Spec Kit cycle figure;
- CSDD traceability matrix screenshot;
- ADR template screenshot;
- tool screenshots.

## 8. Открытые вопросы

1. Should the final publication include a synthetic conceptual diagram? Current text is readable without it.
2. Should story anchors become explicit links to story chapters? This depends on site URL/anchor stability.
3. Should `proves / does_not_prove` remain in English as compact technical keys or be translated in final style pass? Current decision: keep as small pseudo-schema.
4. Should `fitness function` be translated or retained? Current decision: retain as source-native term with Russian explanation.
5. Should `CODEOWNERS` stay? It is useful but optional; if the section feels too governance-heavy, remove it and keep review routing generic.

## 9. Деградационный аудит

### Preserved

- Chapter remains conceptual, not a method catalog.
- ADR/status boundary is strong.
- Generated/reconstructed ADR candidate boundary is strong.
- `Confirmation` does not become evidence chapter.
- SPDD is a bridge to IV, not a deep treatment.
- PWG is only bridged.

### Risks remaining

- Section 2 still names SPDD/Spec Kit/CSDD in one paragraph, though responsibility framing now leads.
- Section 4 has several examples; later style pass may compress if it feels list-like.
- Section 7 still uses one external AI/ADR paper; avoid adding more.
- Some source-native terms remain English; final language pass should check naturalness without replacing exact names.

## Status

Companion sync complete. No hidden essential facts remain only in companion files: the main chapter contains the core distinctions and supporting technical anchors. Companion material now functions as provenance, boundary and future-publication support.
