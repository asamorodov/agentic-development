# P07 — карта содержательных лакун для внешнего поиска

## Итоговая оценка

Внутреннего материала достаточно, чтобы написать содержательную главу III. Но для публикационного текста есть несколько лакун, где нужно не расширение темы, а подтверждение и точная привязка к первичным источникам. Профиль главы остаётся `D2`: bounded discovery по вопросам главы.

Внешний поиск не должен добавлять новые методики и не должен превращать главу в обзор ADR tooling. Его задача — укрепить четыре узких места:

1. ADR as decision-memory practice beyond internal Atlas summary;
2. `Confirmation` / architecture fitness functions as limited confirmation of decisions;
3. CODEOWNERS / ownership boundary as review routing, not full authority;
4. generated/reconstructed ADR as candidate record, not accepted decision.

## Лакуна 1 — публичная практика ADR за пределами внутреннего пересказа

Внутренний материал уже содержит Nygard, Fowler, MADR and AWS. Но в основной главе нельзя ссылаться на досье как источник. Нужно убедиться, что первичные sources достаточны для утверждений:

- ADR записывает context / decision / status / consequences;
- accepted ADR should not be silently rewritten; replacement should happen through a new record / superseding relation;
- richer templates like MADR include alternatives, decision drivers and `Confirmation`;
- AWS-style process treats ADR as reviewed artifact with owner/stakeholders/lifecycle.

### Решение

Внешний поиск нужен не для новых концептов, а для source restoration: Nygard, Fowler, MADR, AWS ADR process. Если эти источники уже доступны через ссылки из внутренних материалов, достаточно проверить первичные страницы and use them directly.

## Лакуна 2 — architecture fitness functions and `Confirmation`

Внутренний материал хорошо объясняет `Confirmation`, но для главы нужен точный внешний якорь на идею architecture fitness function или machine-checkable architectural constraint. Без этого `Confirmation` может выглядеть как авторская интерпретация ADR.

### Вопрос для поиска

Какие первичные или устойчивые источники лучше подтвердят мысль:

> часть архитектурного решения можно подтвердить структурным правилом, контрактной проверкой, ownership review, metric or rollout gate, но такой сигнал не доказывает всё решение.

### Возможные источники

- MADR `Confirmation` as ADR field;
- Neal Ford / evolutionary architecture / architecture fitness functions, если нужен концептуальный якорь;
- ArchUnit or equivalent docs only as example of checkable architectural rule;
- Pact / `can-i-deploy` and `oasdiff` only as examples of interface compatibility confirmation if they не перегружают III.

### Решение

Добавить ограниченный source-restoration. Не разносить все инструменты по основному тексту. Достаточно одного-двух примеров and boundary phrase: “этот сигнал подтверждает только выбранную часть решения”.

## Лакуна 3 — CODEOWNERS and ownership boundary

Внутренний материал использует `CODEOWNERS` как пример владельческого review routing. Для главы III это нужно только как мост между decision memory and authority: code owner review can support confirmation, but does not equal full architectural risk acceptance.

### Вопрос для поиска

Какие первичные GitHub docs точно говорят, что `CODEOWNERS` автоматически запрашивает review and can be required by branch protection?

### Решение

Внешний источник нужен только если глава использует `CODEOWNERS` в основном тексте. Использовать осторожно: `CODEOWNERS` belongs more to XII; in III it can appear as one possible confirmation/review route, not as governance theory.

## Лакуна 4 — generated/reconstructed ADR and LLM boundary

Внутренний материал contains AgenticAKM, generated ADR studies, DRAFT, Context Matters, violation detection and architecture reconstruction. Для главы III важно не всё исследовательское поле, а граница candidate vs accepted.

### Вопрос для поиска

Какие источники могут подтвердить узкое утверждение:

> LLM systems can help draft, recover or check architecture decision records, but the generated/reconstructed record should remain reviewable candidate evidence unless accepted by responsible humans/process.

### Решение

Bounded discovery нужен. Использовать не больше 1–2 источников, если они действительно помогают главе. Не строить обзор AI/ADR literature. Если источники показывают разнородность результатов, это усилит осторожную формулировку: “LLM can assist drafting/reconstruction; authority remains separate”.

## Лакуна 5 — LLM validators / decision gates

Внутренний материал содержит примеры вроде Design Decision Gate, ADR Sync, Mneme ADR compiler. Они полезны, но могут потянуть главу в технический атлас.

### Решение

Не искать широко. Использовать только если черновику понадобится один пример того, как ADR becomes operational projection for agent. Даже тогда писать как pattern, not product survey:

```text
accepted ADR → active decision set → short rule for agent → deterministic checks where possible → human review where judgment is required
```

## Что не искать

- Новые specification frameworks.
- Обзоры всех ADR tools.
- Новые security frameworks for CSDD.
- Полный обзор contract testing.
- Open-source AI policy / governance material; это глава XII.
- Runtime / PWG / process profiles.

## Поисковые вопросы для следующего прохода

1. What do primary ADR sources say about status, superseding and not rewriting accepted decisions?
2. How does MADR define `Confirmation`, and can it support the claim that confirmation is a plan of evidence rather than one test?
3. What is the most compact primary source for architecture fitness functions or architecture tests as limited checks?
4. What do GitHub docs say about `CODEOWNERS` review and branch protection?
5. What credible AI/ADR source supports generated/reconstructed ADR as draft/candidate rather than accepted architectural memory?

## Интеграционное правило

Если внешний поиск найдёт материал, он должен попасть в черновик только одним из трёх способов:

- **integrate now** — источник прямо поддерживает различение главы;
- **source register only** — источник полезен для будущей главы XI/XII/XIII, но не нужен в тексте III;
- **future debt** — источник требует отдельного разбора and would distort this chapter.

## Статус

Bounded external discovery нужен. Лакуна не в количестве внутренних материалов, а в публикационной опоре: глава должна ссылаться на первичные ADR/Confirmation/ownership/generated-ADR sources, а не на внутренние досье and Atlas reports.
