# III. Source register

## Встроенные источники

| Источник | Где используется | Роль |
| --- | --- | --- |
| Michael Nygard, “Documenting Architecture Decisions” | Раздел 5 | Минимальная форма ADR: `Context`, `Decision`, `Status`, `Consequences`; разговор с будущим разработчиком. |
| Martin Fowler, “Architecture Decision Record” | Раздел 5 | ADR как короткая запись в журнале решений. |
| AWS Prescriptive Guidance — ADR process | Раздел 5 | Жизненный цикл ADR, неизменяемость принятой записи, замещение через новую ADR, статус `Superseded`. |
| MADR template | Раздел 4 | Поле `Confirmation` как явное место для описания подтверждения реализации или соблюдения ADR. |
| Evolutionary architecture / fitness function | Раздел 4 | Ограниченная объективная оценка архитектурной характеристики. |
| GitHub CODEOWNERS docs | Раздел 4 | Маршрут ревью владельца области. |
| GitHub branch protection docs | Раздел 4 | Обязательное ревью code owner как gate перед merge. |
| Dhar et al. 2024 LLM/ADD paper | Раздел 7 | Модель может помочь подготовить текст решения, но это не даёт полномочия принятия. |

## Источники в резерве

| Источник | Почему не встроен сейчас |
| --- | --- |
| DRAFT-ing Architectural Design Decisions using LLMs | Поддерживает drafting, но одного AI/ADR-источника достаточно. |
| Context Matters / AgenticAKM / violation detection papers | Уводят главу в литературу generation/validation; лучше для XI/XII/Atlas. |
| Pact / `oasdiff` / ArchUnit / NetArchTest / dependency-cruiser | Инструментальные примеры evidence layer; для XI или Handbook. |
| Detailed AWS best practices | Процессная детализация не нужна после ссылки на AWS ADR process. |
