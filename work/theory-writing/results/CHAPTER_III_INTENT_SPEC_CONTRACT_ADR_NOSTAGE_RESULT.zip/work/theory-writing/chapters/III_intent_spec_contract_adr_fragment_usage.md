# III. Fragment usage

| Фрагмент | Использование в главе | Что не переносилось |
| --- | --- | --- |
| A2 — specification/ADR/contract | Главная матрица различений: specification vs contract, ADR status, `Confirmation`, origin vs status. | Полные синтетические фигуры и technical cards. |
| A3 — specification methodologies | Responsibility framing: specification changes next permitted action; protected profiles without catalog. | Full comparison of SPDD/Spec Kit/CSDD/TDAD. |
| B1 — SPDD contribution | Final transition: specification as delivery artifact, generation/review/sync lifecycle. | OpenSPDD command details and SPDD examples. |
| C1 — specification → PWG | Bridge to working state: spec/contract/ADR do not store owner/block/handoff/evidence state. | Beads/Gas Town mechanics and PWG model. |

## Примечание

Фрагменты использованы для смыслового каркаса главы. Основной текст не должен ссылаться на внутренние фрагменты как на публичные источники.
