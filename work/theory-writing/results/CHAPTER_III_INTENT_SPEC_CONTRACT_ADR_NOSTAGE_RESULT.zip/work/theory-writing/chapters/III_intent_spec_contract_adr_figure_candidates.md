# III. Figure candidates

## Current decision

No mandatory figure is needed in the chapter text yet.

## Allowed future figure

```text
intent → specification → contract → Confirmation → ADR/status → accepted responsibility
```

## Optional future figure

Only if the publication layer needs a visual reminder of the origin/status distinction:

```text
origin ≠ status
agent-drafted / reconstructed → proposed → accepted / rejected / superseded
```

## Rejected for this chapter

- SPDD Canvas figure;
- Spec Kit cycle figure;
- CSDD traceability matrix screenshot;
- ADR template screenshot;
- tool screenshots.
