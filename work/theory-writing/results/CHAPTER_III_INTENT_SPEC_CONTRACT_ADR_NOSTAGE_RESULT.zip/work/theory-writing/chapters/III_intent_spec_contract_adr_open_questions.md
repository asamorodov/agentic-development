# III. Open questions

1. Should the final publication include a synthetic conceptual diagram? Current text is readable without it.
2. Should story anchors become explicit links to story chapters? This depends on site URL/anchor stability.
3. Should `proves / does_not_prove` remain in English as compact technical keys or be translated in final style pass? Current decision: keep as small pseudo-schema.
4. Should `fitness function` be translated or retained? Current decision: retain as source-native term with Russian explanation.
5. Should `CODEOWNERS` stay? It is useful but optional; if the section feels too governance-heavy, remove it and keep review routing generic.
