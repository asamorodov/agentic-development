# III. Atlas usage

| Atlas article | How used | Boundary |
| --- | --- | --- |
| ADR article | Status discipline, accepted/superseded, decision memory, `Confirmation`. | No ADR tooling/tutorial. |
| SPDD article | Bridge to IV; specification as lifecycle artifact. | No deep SPDD in III. |
| Spec Kit article | `spec.md` → `plan.md` → `tasks.md` as typed transitions. | No command chain or workflow catalog. |
| CSDD article | `Constitution` must become traceable; `Constitution Check PASS` can be decorative. | No security/governance chapter. |
| TDAD comparative | Only background for contract/evidence distinction. | Not named in main text. |
| BMAD | Not used. | Process/role layer not needed here. |
