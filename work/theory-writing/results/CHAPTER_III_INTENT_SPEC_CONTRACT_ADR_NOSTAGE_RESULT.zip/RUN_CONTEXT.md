Executor package: CHAPTER_III_INTENT_SPEC_CONTRACT_ADR
Current record: r031
Type: final
Expected output: work/theory-writing/chapters/III_intent_spec_contract_adr_passes/31_final_package_readiness.md
