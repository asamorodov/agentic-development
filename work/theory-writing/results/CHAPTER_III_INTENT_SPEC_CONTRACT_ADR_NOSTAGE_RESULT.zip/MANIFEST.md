# MANIFEST

## Result

Primary chapter candidate:

- `work/theory-writing/chapters/III_intent_spec_contract_adr.md`

Companion files:

- `work/theory-writing/chapters/III_intent_spec_contract_adr_source_register.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_fragment_usage.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_atlas_usage.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_dossier_gap_notes.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_external_discovery_log.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_story_anchors.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_figure_candidates.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_open_questions.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_degradation_and_duplication_audit.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_readiness_report.md`


## Pass outputs

The package produced 30 pass outputs:

- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/01_context_contract.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/02_skeleton_frame.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/03_fragment_salvage.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/04_adr_use.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/05_method_use.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/06_dossier_gap.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/07_content_gap.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/08_content_gap.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/09_external_unfolding.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/10_story_anchors.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/11_visual_policy.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/12_reader_path_outline.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/13_first_synthetic_draft.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/14_fragment_integration.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/15_atlas_plan.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/16_dossier_gap.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/17_content_repair.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/18_neighbor_boundaries.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/19_source_provenance.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/20_language_1.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/21_language_2.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/22_editorial_argument.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/23_editorial_density.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/24_editorial_anticatalog.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/25_entry_structure_sequence.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/26_companion_sync.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/27_style_defect_audit.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/28_selective_natural_rewrite.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/29_guarded_final_style.md`
- `work/theory-writing/chapters/III_intent_spec_contract_adr_passes/30_final_regression.md`


## Root control files

- `MANIFEST.md`
- `VERIFY.md`
- `RESUME.md`
- `STATUS.md`
- `UPDATE_INSTRUCTIONS.md`

## Scope note

The package does not update Skeleton, routing maps or the global blueprint. It only produces chapter III and its companion files.
