# UPDATE INSTRUCTIONS

## `work/discourse.md`

Add or update the chapter III entry with:

- canonical candidate: `work/theory-writing/chapters/III_intent_spec_contract_adr.md`;
- status: no-stage package result accepted as chapter III candidate, pending cross-chapter integration;
- core function: separates specification, contract, ADR, `Confirmation`, generated/reconstructed ADR candidate status and project acceptance;
- bridge: chapter IV should deepen SPDD as a lifecycle where specification becomes the primary working artifact.

Do not rewrite the full discourse spine from this package alone.

## `WORKING_DOCUMENTS_MAP.md`

Register the following files under chapter III:

- `work/theory-writing/chapters/III_intent_spec_contract_adr.md` — main chapter candidate;
- `work/theory-writing/chapters/III_intent_spec_contract_adr_source_register.md`;
- `work/theory-writing/chapters/III_intent_spec_contract_adr_fragment_usage.md`;
- `work/theory-writing/chapters/III_intent_spec_contract_adr_atlas_usage.md`;
- `work/theory-writing/chapters/III_intent_spec_contract_adr_dossier_gap_notes.md`;
- `work/theory-writing/chapters/III_intent_spec_contract_adr_external_discovery_log.md`;
- `work/theory-writing/chapters/III_intent_spec_contract_adr_story_anchors.md`;
- `work/theory-writing/chapters/III_intent_spec_contract_adr_figure_candidates.md`;
- `work/theory-writing/chapters/III_intent_spec_contract_adr_open_questions.md`;
- `work/theory-writing/chapters/III_intent_spec_contract_adr_degradation_and_duplication_audit.md`;
- `work/theory-writing/chapters/III_intent_spec_contract_adr_readiness_report.md`.

Do not change Skeleton, routing maps or the global blueprint from this package.
