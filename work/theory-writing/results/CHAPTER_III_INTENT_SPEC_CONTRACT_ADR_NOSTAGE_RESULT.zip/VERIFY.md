# VERIFY
## Chain integrity
- Pass outputs found: 30 / 30.
- Missing pass outputs: none.
- The final main chapter is copied from `29_guarded_final_style.md`; it was not rewritten during final assembly.
- Readiness report is copied from `30_final_regression.md`.
- Companion files are assembled from the explicit companion sync and final readiness outputs.
- No Skeleton, routing map or global blueprint file was modified by this final assembly.

## Expected files
- OK: `work/theory-writing/chapters/III_intent_spec_contract_adr.md`
- OK: `work/theory-writing/chapters/III_intent_spec_contract_adr_source_register.md`
- OK: `work/theory-writing/chapters/III_intent_spec_contract_adr_fragment_usage.md`
- OK: `work/theory-writing/chapters/III_intent_spec_contract_adr_atlas_usage.md`
- OK: `work/theory-writing/chapters/III_intent_spec_contract_adr_dossier_gap_notes.md`
- OK: `work/theory-writing/chapters/III_intent_spec_contract_adr_external_discovery_log.md`
- OK: `work/theory-writing/chapters/III_intent_spec_contract_adr_story_anchors.md`
- OK: `work/theory-writing/chapters/III_intent_spec_contract_adr_figure_candidates.md`
- OK: `work/theory-writing/chapters/III_intent_spec_contract_adr_open_questions.md`
- OK: `work/theory-writing/chapters/III_intent_spec_contract_adr_degradation_and_duplication_audit.md`
- OK: `work/theory-writing/chapters/III_intent_spec_contract_adr_readiness_report.md`

## Readiness criteria
- Specification, contract and ADR are separated.
- Generated/reconstructed ADR remains a candidate until accepted.
- `Confirmation` is only a bridge to future evidence.
- Design Decision Gate and CODEOWNERS remain boundary examples, not a governance chapter.
- External discovery did not expand the scope into a source survey.
- Bridge to chapter IV is present.
