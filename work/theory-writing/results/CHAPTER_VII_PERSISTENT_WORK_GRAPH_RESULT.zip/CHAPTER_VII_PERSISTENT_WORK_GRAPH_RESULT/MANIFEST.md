# MANIFEST — Chapter VII Persistent Work Graph result

## Основные файлы

- `work/theory-writing/chapters/VII_persistent_work_graph.md` — финальная редакция главы.
- `work/theory-writing/chapters/VII_persistent_work_graph_readiness_report.md` — readiness/regression report.

## Companion files

- `work/theory-writing/chapters/VII_persistent_work_graph_source_register.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_fragment_usage.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_atlas_usage.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_dossier_gap_notes.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_external_discovery_log.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_story_anchors.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_figure_candidates.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_open_questions.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_degradation_and_duplication_audit.md`

## Pass reports

- `work/theory-writing/chapters/VII_persistent_work_graph_passes/01_01_context_and_boundary.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/02_02_input_corpus_map.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/03_03_source_register_seed.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/04_04_external_discovery.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/05_05_chapter_frame.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/06_06_cross_example.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/07_07_source_family_deepening.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/08_08_interface_and_current_practice.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/09_09_argument_skeleton.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/10_10_full_draft.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/11_11_active_material_intake.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/12_12_visual_layer.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/13_13_natural_russian_rewrite.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/14_14_structure_and_individuality.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/15_15_companion_files.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/16_16_final_revision.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/17_17_readiness_report.md`
- `work/theory-writing/chapters/VII_persistent_work_graph_passes/18_final_package_readiness.md`

## Assets

- `content/assets/theory-images/beads-task-graph-memory.svg` — локальный SVG-asset, на который ссылается глава.

## File inventory
- MANIFEST.md
- RESUME.md
- VERIFY.md
- content/assets/theory-images/beads-task-graph-memory.svg
- work/theory-writing/chapters/VII_persistent_work_graph.md
- work/theory-writing/chapters/VII_persistent_work_graph_atlas_usage.md
- work/theory-writing/chapters/VII_persistent_work_graph_degradation_and_duplication_audit.md
- work/theory-writing/chapters/VII_persistent_work_graph_dossier_gap_notes.md
- work/theory-writing/chapters/VII_persistent_work_graph_external_discovery_log.md
- work/theory-writing/chapters/VII_persistent_work_graph_figure_candidates.md
- work/theory-writing/chapters/VII_persistent_work_graph_fragment_usage.md
- work/theory-writing/chapters/VII_persistent_work_graph_open_questions.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/01_01_context_and_boundary.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/02_02_input_corpus_map.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/03_03_source_register_seed.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/04_04_external_discovery.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/05_05_chapter_frame.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/06_06_cross_example.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/07_07_source_family_deepening.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/08_08_interface_and_current_practice.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/09_09_argument_skeleton.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/10_10_full_draft.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/11_11_active_material_intake.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/12_12_visual_layer.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/13_13_natural_russian_rewrite.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/14_14_structure_and_individuality.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/15_15_companion_files.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/16_16_final_revision.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/17_17_readiness_report.md
- work/theory-writing/chapters/VII_persistent_work_graph_passes/18_final_package_readiness.md
- work/theory-writing/chapters/VII_persistent_work_graph_readiness_report.md
- work/theory-writing/chapters/VII_persistent_work_graph_source_register.md
- work/theory-writing/chapters/VII_persistent_work_graph_story_anchors.md
