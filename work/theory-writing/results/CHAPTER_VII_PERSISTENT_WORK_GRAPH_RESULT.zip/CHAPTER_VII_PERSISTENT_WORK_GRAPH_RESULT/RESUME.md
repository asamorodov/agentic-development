# RESUME — что сделать после применения результата

## Основное применение

1. Перенести `work/theory-writing/chapters/VII_persistent_work_graph.md` в основной репозиторий как текущую редакцию главы VII.
2. Перенести companion files рядом с главой или в принятую директорию рабочих отчётов.
3. Убедиться, что `content/assets/theory-images/beads-task-graph-memory.svg` существует по пути, ожидаемому сайтом.

## Обновить состояние основного репозитория

После применения результата в основной репозиторий нужно обновить:

- `work/discourse.md` — зафиксировать, что глава VII собрана в no-stage режиме и готова как Persistent Work Graph chapter.
- `work/theory-writing/WORKING_DOCUMENTS_MAP.md` — отметить `VII_persistent_work_graph.md` как актуальный рабочий файл главы VII и перечислить companion files.
- `work/APPLY_NOTES.md` — указать, какие файлы добавлены/обновлены и что нужно проверить в визуальном слое.

Эти state files не были изменены внутри пакета, потому что финальный лист требовал собрать результат без изменения Skeleton, карт маршрутизации, blueprint или исходных atlas articles. Обновление должно произойти при применении результата к основному репозиторию.

## Следующая глава

Глава VII завершает вопрос «где находится работа». Глава VIII должна продолжить вопросом «каким способом действовать с этим состоянием»: investigation, repair, triage, escalation, decision memo, wait, cleanup or acceptance path.
