# RESUME — Applying Chapter X Gas Town / Beads result

## What to apply

Copy these files into the main repository:

- `work/theory-writing/chapters/X_gas_town_beads.md`
- `work/theory-writing/chapters/X_gas_town_beads_source_register.md`
- `work/theory-writing/chapters/X_gas_town_beads_fragment_usage.md`
- `work/theory-writing/chapters/X_gas_town_beads_atlas_usage.md`
- `work/theory-writing/chapters/X_gas_town_beads_dossier_gap_notes.md`
- `work/theory-writing/chapters/X_gas_town_beads_external_discovery_log.md`
- `work/theory-writing/chapters/X_gas_town_beads_story_anchors.md`
- `work/theory-writing/chapters/X_gas_town_beads_figure_candidates.md`
- `work/theory-writing/chapters/X_gas_town_beads_open_questions.md`
- `work/theory-writing/chapters/X_gas_town_beads_degradation_and_duplication_audit.md`
- `work/theory-writing/chapters/X_gas_town_beads_readiness_report.md`

## Repository state updates still needed

After applying the chapter files to the main repository, update:

1. `work/discourse.md`
   - Record that Chapter X Gas Town / Beads has been written through the no-stage chapter package.
   - Note core axis: many agentic work streams require serviced flow, not only durable work state.
   - Note final bridge: Chapter XI should handle verification material / result trust, not flow organization.

2. `work/theory-writing/WORKING_DOCUMENTS_MAP.md`
   - Add the new chapter file and companion files.
   - Mark `X_gas_town_beads.md` as the current Chapter X result produced by this package.
   - Record that the chapter uses two figures: pressure-to-mechanism stack and two-tier Beads flow.

3. `work/APPLY_NOTES.md` if present in the main repository
   - Record copy/application of Chapter X files.
   - Verify figure relative paths.
   - Note no Skeleton/routing/blueprint/Atlas source files are changed by this result.

## Follow-up checks

- Verify `../assets/...` paths from the final chapter location.
- Do not add optional `gastown-basic-workflow.svg` unless the chapter later becomes hard to follow.
- Keep supporting stories short; do not expand them into separate case studies inside Chapter X.
