# MANIFEST — Chapter IX execution environment / runtime rights

Generated: 2026-06-15T13:39:30

## Main result files

| Path | Size bytes | SHA256 |
|---|---:|---|
| `work/theory-writing/chapters/IX_execution_environment_runtime_rights.md` | 58686 | `3735a60b925fdf1908c49b491510921b4697452adc6b734d7aa54fe944148af2` |
| `work/theory-writing/chapters/IX_execution_environment_runtime_rights_source_register.md` | 10702 | `b03699380b483fe133753eebc29e77b1a2c27eb7647f0ece83378e4338a277be` |
| `work/theory-writing/chapters/IX_execution_environment_runtime_rights_fragment_usage.md` | 1385 | `b286a337b862c8833a9c3cf855f035028fb5124bcdc2ab4ad8cd2d7e6d0847ad` |
| `work/theory-writing/chapters/IX_execution_environment_runtime_rights_atlas_usage.md` | 1206 | `fea674f2b0cef6ccb8fce018f9e2625d248a319b7e18b58cbcc4c7dfe01f74fb` |
| `work/theory-writing/chapters/IX_execution_environment_runtime_rights_dossier_gap_notes.md` | 1357 | `d2054d0c3a77bd8592f3073c6a6db7e955ef867b2450901e6d0a3ec333bc7d2e` |
| `work/theory-writing/chapters/IX_execution_environment_runtime_rights_external_discovery_log.md` | 985 | `0dad3feca7950b8a87a9fa1372c399e01bf92ed1ecc870b282194181c6791478` |
| `work/theory-writing/chapters/IX_execution_environment_runtime_rights_story_anchors.md` | 1175 | `f666f00ad79e459b479961813ec306744626936e485d52164dc50cba0b17d487` |
| `work/theory-writing/chapters/IX_execution_environment_runtime_rights_figure_candidates.md` | 2579 | `917a945aae9b071f387099d61751e15b5999af5aa053f094f52ba01db254cc78` |
| `work/theory-writing/chapters/IX_execution_environment_runtime_rights_open_questions.md` | 1658 | `21ac60d51c826c91b34964f3c5fe7ce6f2921581d1459285855979a7507f1665` |
| `work/theory-writing/chapters/IX_execution_environment_runtime_rights_degradation_and_duplication_audit.md` | 2469 | `be46d9501e71df0b18b70ad32441b84233a52ae1bf24326247daf06256707225` |
| `work/theory-writing/chapters/IX_execution_environment_runtime_rights_readiness_report.md` | 11433 | `78afb8a1a44a49c882e140a1ac6bbbd204fe2ea18030a3b5f71fc62babf66587` |

## Pass reports included

All Markdown pass outputs from `work/theory-writing/chapters/IX_execution_environment_runtime_rights_passes/` are included in the archive.

## Excluded by design

- Hidden payload `z3k9p.dat` is not included.
- Source archive unpacking script and transient worksheets are not included.
- Skeleton, routing maps, blueprint, Atlas source articles and repository state files are not modified by this result archive.

## Result archive

- `work/result/CHAPTER_IX_EXECUTION_ENVIRONMENT_RUNTIME_RIGHTS_RESULT.zip`
- Archive SHA256 is stored beside the archive in `work/result/ARCHIVE_SHA256.txt` after final ZIP creation.
