#!/usr/bin/env python3
import base64, gzip, hashlib, json, sys, zipfile
from pathlib import Path
STATE_FILE = Path('.state.json')
DATA_FILE = Path('z3k9p.dat')
def _load_payload():
    raw = gzip.decompress(base64.b64decode(DATA_FILE.read_text(encoding='ascii')))
    return json.loads(raw.decode('utf-8'))
def _decode_record(payload, key):
    raw = gzip.decompress(base64.b64decode(payload['records'][key].encode('ascii')))
    return json.loads(raw.decode('utf-8'))
def _load_state(payload):
    if STATE_FILE.exists(): return json.loads(STATE_FILE.read_text(encoding='utf-8'))
    return {'current': payload['entry'], 'done': [], 'last': None}
def _save_state(state):
    STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
def _sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for c in iter(lambda:f.read(1024*1024), b''): h.update(c)
    return h.hexdigest()
def _write(files):
    out=[]
    for name,text in files.items():
        p=Path(name); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(text, encoding='utf-8'); out.append(name)
    return out
def _check(req):
    missing=[x for x in req if not Path(x).exists()]
    if missing:
        print('Не найдены обязательные выходные файлы предыдущего задания:')
        for x in missing: print('-',x)
        print('Сначала запиши эти файлы, затем снова запусти python q8v4m.py')
        return False
    return True
def emergency():
    out=Path('emergency_state.zip')
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        for p in Path('.').rglob('*'):
            if p.is_file() and p.name!=out.name: z.write(p,p.as_posix())
    print(f'Аварийный архив создан: {out}')
def main():
    if len(sys.argv)>1 and sys.argv[1]=='emergency': emergency(); return
    payload=_load_payload(); state=_load_state(payload); cur=state.get('current')
    if not cur: print('Пакет уже завершён.'); return
    rec=_decode_record(payload,cur)
    if not _check(rec.get('require_before',[])): return
    written=_write(rec.get('files',{}))
    state['done'].append({'key':cur,'written':written,'sha':{x:_sha(x) for x in written if Path(x).exists()}})
    state['last']=cur; state['current']=rec.get('next'); _save_state(state)
    print(rec.get('message') or 'Материализован следующий рабочий лист.')
if __name__=='__main__': main()
