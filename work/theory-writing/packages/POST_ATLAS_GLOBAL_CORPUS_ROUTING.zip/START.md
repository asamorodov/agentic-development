# POST_ATLAS_GLOBAL_CORPUS_ROUTING — repo-bound executor package

Этот пакет запускает общий слой подготовки для будущих глав теории. Он **не самодостаточен**: пакет не содержит весь корпус источников и должен работать рядом с отдельно развёрнутым репозиторием.

## Как запускать

Вариант A — из корня репозитория:

```bash
python /path/to/this-package/q8v4m.py --repo .
```

Вариант B — из каталога пакета:

```bash
python q8v4m.py --repo /path/to/repository/root
```

После запуска открой созданный `.md`-файл и выполни инструкцию. Затем снова запускай тот же Python-скрипт, пока не появится финальный рабочий лист.

Если работа прерывается и продолжить невозможно, выполни:

```bash
python q8v4m.py emergency
```

и отдай созданный аварийный архив пользователю. Аварийный архив содержит состояние executor package, но не полный репозиторий.

## Что делает пакет

Пакет создаёт repo-level routing layer для будущих глав:

- список глав и границы scope;
- Atlas → chapter routing;
- A/B/C fragment routing;
- dossier gap map;
- story anchor routing;
- external source discovery profiles;
- visual candidate routing;
- chapter package input matrix;
- readiness report.

Пакет не пишет главы, не создаёт per-chapter plans, не переписывает Skeleton, Атлас или A/B/C-фрагменты и не запускает внешний поиск.

## Target plan snapshot

Точный план, из которого собран пакет, сохранён рядом как `TARGET_PLAN_SNAPSHOT.md`.
