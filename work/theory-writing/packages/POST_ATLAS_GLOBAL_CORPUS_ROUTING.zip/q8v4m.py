#!/usr/bin/env python3
from __future__ import annotations
import base64, gzip, json, sys, shutil, os
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
BOX = SCRIPT_DIR / 'z3k9p.dat'
STATE = SCRIPT_DIR / '.q8v4m_state.json'


def _decode_blob(text: str):
    raw = gzip.decompress(base64.b64decode(text.encode('ascii')))
    return json.loads(raw.decode('utf-8'))


def _load_box():
    return _decode_blob(BOX.read_text(encoding='ascii'))


def _parse_repo_arg():
    args = sys.argv[1:]
    if '--repo' in args:
        i = args.index('--repo')
        if i + 1 >= len(args):
            print('После --repo нужно указать путь к корню репозитория.'); sys.exit(2)
        return Path(args[i+1]).expanduser().resolve()
    if os.environ.get('REPO_ROOT'):
        return Path(os.environ['REPO_ROOT']).expanduser().resolve()
    return None


def _looks_like_repo(p: Path) -> bool:
    return (p / 'work').exists() and ((p / 'work' / 'theory-writing').exists() or (p / 'START.md').exists())


def _find_repo_root():
    explicit = _parse_repo_arg()
    if explicit:
        return explicit
    candidates = [Path.cwd().resolve(), SCRIPT_DIR]
    candidates += list(Path.cwd().resolve().parents)[:4]
    candidates += list(SCRIPT_DIR.parents)[:4]
    seen = set()
    for c in candidates:
        if c in seen: continue
        seen.add(c)
        if _looks_like_repo(c):
            return c
    return Path.cwd().resolve()


def _load_state(box):
    if STATE.exists():
        return json.loads(STATE.read_text(encoding='utf-8'))
    return {'current': box['entry'], 'active': True}


def _save_state(state):
    STATE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')


def _write(path, content):
    p = SCRIPT_DIR / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding='utf-8')


def _missing(repo_root: Path, paths):
    miss = []
    for raw in paths:
        p = Path(raw)
        if not p.is_absolute():
            p = repo_root / p
        if not p.exists():
            miss.append(raw)
    return miss


def _pack_interrupted():
    (SCRIPT_DIR / 'INTERRUPTED.md').write_text('Работа прервана до нормального завершения. Архив содержит состояние executor package, но не полный репозиторий.\n', encoding='utf-8')
    if not (SCRIPT_DIR / 'RESUME.md').exists():
        (SCRIPT_DIR / 'RESUME.md').write_text('Для продолжения распакуйте архив рядом с репозиторием и снова запустите Python-скрипт с тем же --repo.\n', encoding='utf-8')
    base = shutil.make_archive(str(SCRIPT_DIR / 'interrupted_state'), 'zip', SCRIPT_DIR)
    print(f'Собран аварийный архив: {base}')


def main():
    if len(sys.argv) > 1 and sys.argv[1] == 'emergency':
        _pack_interrupted(); return
    repo_root = _find_repo_root()
    box = _load_box(); state = _load_state(box)
    if not state.get('active', True):
        print('Текущий материал уже был выдан. Выполни созданный рабочий лист; если работа прервана, используй emergency-команду.'); return
    item = _decode_blob(box['records'][state['current']])
    miss = _missing(repo_root, item.get('need', []))
    if miss:
        print('Не найдены требуемые файлы или каталоги в репозитории:', repo_root)
        for m in miss: print('-', m)
        print('Запусти пакет в корне развёрнутого репозитория или укажи путь: python q8v4m.py --repo /path/to/repo')
        return
    (SCRIPT_DIR / 'RUN_CONTEXT.md').write_text(f'Executor package: {box.get("package")}\nRepository root: {repo_root}\nCurrent record: {state["current"]}\n', encoding='utf-8')
    for p,c in item.get('emit', {}).items():
        _write(p, c)
    nxt = item.get('next')
    state['current'] = nxt if nxt else state['current']; state['active'] = bool(nxt); _save_state(state)
    if item.get('show'): print(item['show'])

if __name__ == '__main__': main()
