#!/usr/bin/env python3
from pathlib import Path
import base64, gzip, json, zipfile, sys, datetime, hashlib

DATA = Path('z3k9p.dat')
STATE = Path('.q8v4m_state.json')

def load_payload():
    raw = gzip.decompress(base64.b64decode(DATA.read_text(encoding='ascii')))
    return json.loads(raw.decode('utf-8'))

def load_state(entry):
    if STATE.exists():
        return json.loads(STATE.read_text(encoding='utf-8'))
    return {'current': entry, 'need': []}

def save_state(state):
    STATE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def check_need(need):
    missing=[]
    empty=[]
    for x in need:
        p=Path(x)
        if not p.exists():
            missing.append(x)
        elif p.is_file() and p.stat().st_size == 0:
            empty.append(x)
    if missing or empty:
        print('Не все выходные файлы предыдущего задания найдены.')
        if missing:
            print('Отсутствуют:')
            for x in missing: print('-', x)
        if empty:
            print('Пустые:')
            for x in empty: print('-', x)
        print('Сначала запиши требуемые файлы, затем снова запусти этот скрипт.')
        return False
    return True

def emergency():
    stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
    out=Path(f'emergency_package_{stamp}.zip')
    Path('INTERRUPTED.md').write_text('Работа прервана. В архив упаковано текущее состояние файловой среды.\n', encoding='utf-8')
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in Path('.').rglob('*'):
            if p.is_file() and p.name != out.name:
                z.write(p, p)
    print(out)

def main():
    if len(sys.argv) > 1 and sys.argv[1] == 'emergency':
        emergency(); return
    payload=load_payload()
    state=load_state(payload['entry'])
    if not check_need(state.get('need', [])):
        return
    cur=state.get('current')
    if cur is None:
        print('Работа уже завершена или ожидает финальной инструкции.')
        return
    item=payload['items'][cur]
    for name, text in item['files'].items():
        Path(name).write_text(text, encoding='utf-8')
    state={'current': item.get('next'), 'need': item.get('need', [])}
    save_state(state)
    md=[x for x in item['files'] if x.endswith('.md')]
    if md:
        print(f'Открой файл {md[0]} и выполни инструкцию.')
    else:
        print('Материализованы файлы текущего задания.')

if __name__ == '__main__':
    main()
