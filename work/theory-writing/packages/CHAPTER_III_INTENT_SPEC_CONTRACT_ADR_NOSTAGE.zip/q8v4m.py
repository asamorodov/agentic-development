#!/usr/bin/env python3
from __future__ import annotations
import base64, gzip, json, sys, shutil, time, zipfile
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
BOX = SCRIPT_DIR / 'z3k9p.dat'
STATE = SCRIPT_DIR / '.q8v4m_state.json'
LOG = SCRIPT_DIR / '.q8v4m_chain_log.jsonl'

def _decode_blob(text: str):
    raw = gzip.decompress(base64.b64decode(text.encode('ascii')))
    return json.loads(raw.decode('utf-8'))

def _load_box():
    return _decode_blob(BOX.read_text(encoding='ascii'))

def _load_state(box):
    if STATE.exists():
        return json.loads(STATE.read_text(encoding='utf-8'))
    return {'current': box['entry'], 'active': True, 'stage': 1}

def _save_state(state):
    STATE.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')

def _write(path, content):
    p = SCRIPT_DIR / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding='utf-8')

def _missing(paths):
    return [raw for raw in paths if not (SCRIPT_DIR / raw).exists()]

def _log(event, **data):
    row = {'time': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'event': event}
    row.update(data)
    with LOG.open('a', encoding='utf-8') as f:
        f.write(json.dumps(row, ensure_ascii=False) + '\n')

def _state_report(box, state, reason='interrupted'):
    current = state.get('current')
    item = None
    if current and current in box['records']:
        item = _decode_blob(box['records'][current])
    required = item.get('need', []) if item else []
    missing = _missing(required) if item else []
    sheet = item.get('sheet') if item else None
    output = item.get('output') if item else None
    text = [
        f'# INTERRUPTION_STATE — {box.get("package")}', '',
        f'Reason: `{reason}`',
        f'Current record: `{current}`',
        f'Current sheet: `{sheet}`',
        f'Expected output: `{output}`', '',
        '## Required files for current record',
    ]
    if required:
        for p in required:
            text.append(f'- `{p}` — {"exists" if (SCRIPT_DIR/p).exists() else "missing"}')
    else:
        text.append('- none')
    text += ['', '## Missing', *([f'- `{m}`' for m in missing] if missing else ['- none']), '',
             '## Resume recommendation',
             'If required files are missing, complete only the current materialized sheet. Do not reconstruct earlier outputs, do not create future pass reports in bulk, and do not jump to final packaging.', '',
             'If the current sheet output already exists, run `python q8v4m.py` once to materialize the next sheet.']
    (SCRIPT_DIR / 'INTERRUPTION_STATE.md').write_text('\n'.join(text) + '\n', encoding='utf-8')

def _safe_zip(name: str):
    out = SCRIPT_DIR / f'{name}.zip'
    if out.exists(): out.unlink()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in SCRIPT_DIR.rglob('*'):
            if not p.is_file(): continue
            rel = p.relative_to(SCRIPT_DIR).as_posix()
            if rel.endswith('.zip'): continue
            if rel.startswith('__pycache__/'): continue
            z.write(p, rel)
    return str(out)

def _pack_interrupted(box, state):
    _state_report(box, state, 'emergency')
    (SCRIPT_DIR / 'INTERRUPTED.md').write_text('Работа прервана до нормального завершения. Архив содержит доступное состояние executor package. См. INTERRUPTION_STATE.md.\n', encoding='utf-8')
    base = _safe_zip('interrupted_state')
    print(f'Собран аварийный архив: {base}')

def main():
    box = _load_box(); state = _load_state(box)
    if len(sys.argv) > 1 and sys.argv[1] == 'emergency':
        _pack_interrupted(box, state); return
    if len(sys.argv) > 1 and sys.argv[1] == 'continue':
        print('В этом варианте пакета нет плановых стадий. Продолжаю как обычный запуск одного следующего листа.')
    if not state.get('active', True):
        print('Текущий материал уже был выдан. Выполни созданный рабочий лист; если работа прервана, используй emergency-команду.'); return
    current = state['current']
    item = _decode_blob(box['records'][current])
    miss = _missing(item.get('need', []))
    if miss:
        _state_report(box, state, 'missing-required-files')
        print('Не найдены требуемые файлы предыдущего действия:')
        for m in miss: print('-', m)
        print('Сначала запиши эти файлы. Не восстанавливай прошлые outputs по памяти; при сомнении используй emergency-команду.')
        return
    (SCRIPT_DIR / 'RUN_CONTEXT.md').write_text(f'Executor package: {box.get("package")}\nCurrent record: {current}\nType: {item.get("type")}\nExpected output: {item.get("output")}\n', encoding='utf-8')
    for p,c in item.get('emit', {}).items(): _write(p, c)
    _log('emit', record=current, type=item.get('type'), emitted=list(item.get('emit', {}).keys()), expected_output=item.get('output'))
    nxt = item.get('next')
    state['current'] = nxt if nxt else current; state['active'] = bool(nxt); _save_state(state)
    if item.get('show'): print(item['show'])
if __name__ == '__main__': main()
