# Post-Atlas per-chapter target plan blueprint

Статус: proposal / blueprint для планов отдельных глав.  
Дата: 2026-06-13.  
Основание: Skeleton V5, `00_spine_map`, завершённый Атлас, post-atlas routing documents, принятый atlas language/style tail.

Этот blueprint описывает, как строить **target-group plan для одной конкретной главы** после того, как общий corpus routing layer уже подготовил карты входов. Он не должен заново строить маршрутизацию всего корпуса. Его задача — взять готовые routing maps и превратить их в рабочий plan для написания одной главы.

## 1. Главное различие уровней

Общий routing layer отвечает на вопрос:

> Какие материалы вообще куда относятся?

Per-chapter target plan отвечает на другой вопрос:

> Как из уже отобранных материалов написать одну сильную главу без превращения её в каталог методов или source dump?

Поэтому в chapter plan не надо повторять глобальную работу: всеобщую Atlas-map, полный fragment inventory, общий story routing, общий visual routing and global external discovery map. Глава читает нужный slice этих документов и работает только со своим scope.

## 2. Структура target-group plan

План главы должен иметь обычную форму:

1. **Обрабатываемые target files** — глава и companion files.
2. **Read-only inputs** — управляющие документы и chapter-specific materials from routing matrix.
3. **Prompt queue** — проходы для package execution.
4. **Readiness criteria** — что Final обязан проверить.

## 3. Outputs главы

Минимальный набор:

```text
work/theory-writing/chapters/<chapter_id>.md
work/theory-writing/chapters/<chapter_id>_source_register.md
work/theory-writing/chapters/<chapter_id>_atlas_usage.md
work/theory-writing/chapters/<chapter_id>_fragment_usage.md
work/theory-writing/chapters/<chapter_id>_dossier_gap_notes.md
work/theory-writing/chapters/<chapter_id>_external_discovery_log.md   # only if discovery module is enabled
work/theory-writing/chapters/<chapter_id>_story_anchors.md
work/theory-writing/chapters/<chapter_id>_figure_candidates.md
work/theory-writing/chapters/<chapter_id>_open_questions.md
work/theory-writing/chapters/<chapter_id>_degradation_and_duplication_audit.md
work/theory-writing/chapters/<chapter_id>_readiness_report.md
```

Если глава не использует external discovery, `external_discovery_log` можно заменить коротким note в `source_register` or `open_questions`; не нужно создавать пустой тяжёлый log только ради симметрии.

## 4. Standard inputs

Каждый chapter package читает:

```text
START.md
work/discourse.md
work/theory-writing/fragments/00_spine_map.md
work/skeletons/THEORETICAL_SYNTHESIS_REBUILT_SKELETON_V5_POST_ATLAS.md
work/theory-writing/CORE_NODES_WRITING_PLAN.md
work/theory-writing/WORKING_DOCUMENTS_MAP.md
work/theory-writing/reports/POST_ATLAS_CHAPTER_PACKAGE_INPUT_MATRIX.md
work/theory-writing/reports/POST_ATLAS_ATLAS_TO_CHAPTER_ROUTING_MAP.md
work/theory-writing/reports/POST_ATLAS_FRAGMENT_TO_CHAPTER_ROUTING_MAP.md
work/theory-writing/reports/POST_ATLAS_DOSSIER_TO_CHAPTER_GAP_MAP.md
work/theory-writing/reports/POST_ATLAS_STORY_ANCHOR_ROUTING_MAP.md
work/theory-writing/reports/POST_ATLAS_EXTERNAL_SOURCE_DISCOVERY_MAP.md
work/theory-writing/reports/POST_ATLAS_VISUAL_CANDIDATE_ROUTING_MAP.md
protocols/rules/russian-language.md
protocols/rules/language-style-rules.md
protocols/rules/human-technical-style.md
protocols/rules/source-and-provenance.md
protocols/rules/content-preservation.md
protocols/rules/fragment-defect-analysis-and-repair.md
```

Chapter-specific inputs must be listed explicitly by path:

- selected A/B/C fragments;
- selected Atlas articles;
- selected dossiers;
- selected stories;
- selected external seed sources, if any;
- selected local assets or visual queues.

No `relevant files` placeholders.

## 5. Discovery is a module, not an empty pass

The chapter plan builder must read the global discovery profile for the chapter and choose one of these variants.

### Variant A — no discovery module

Use when internal materials are enough. The plan has no fake discovery passes. Source/provenance is handled in the normal source register and regression checks.

### Variant B — provenance/restoration module

Use when claims or figures need primary-source restoration. Add one source-restoration pass before drafting or before source/provenance, depending on the chapter.

### Variant C — content discovery module

Use when the chapter has a real content gap. Add discovery + reading/unfolding + integration-decision passes.

### Variant D — two-hop discovery module

Use when the first source reading may reveal new important documents, terms, diagrams, authors or research lines. Add second-hop decision explicitly.

Important: if a chapter does not need discovery, do not add short confirming passes like “P07–P08: no discovery”. That only creates ritual noise. The decision belongs in the chapter contract and source register.

## 6. Base per-chapter queue without external discovery

This is the default for a chapter whose materials are already sufficiently routed and whose external profile is `D0` or light `D1`.

```text
P01 — context restore and chapter contract from routing maps
P02 — skeleton / 00_spine / neighboring chapter alignment
P03 — local fragment salvage: use / supersede / repair
P04 — local Atlas integration plan: concepts, boundaries, do-not-distort notes
P05 — local dossier gap check: only important missing distinctions or details
P06 — story and visual selection for this chapter
P07 — argument outline / reader path
P08 — first synthesis draft
P09 — fragment integration pass
P10 — Atlas integration pass
P11 — dossier/story/visual integration pass
P12 — anti-catalog pass: argument over method list
P13 — cross-chapter boundary and terminology pass
P14 — source/provenance pass
P15 — language pass 1
P16 — language pass 2
P17 — general editorial repair 1
P18 — general editorial repair 2
P19 — general editorial repair 3
P20 — chapter entry / public structure / sequence pass
P21 — companion sync
P22 — style defect audit
P23 — selective natural rewrite
P24 — guarded final human technical style pass
P25 — final regression and readiness check
Final — package outputs, discourse/map update instructions, checks
```

This keeps the accepted atlas tail: language first, then repair/editorial, then entry/sequence, companion sync, style defect audit, selective natural rewrite, guarded final style.

## 7. Added module for content discovery

If the global routing layer marks the chapter as `D2` or `D3`, insert the module after P05 and before outline/draft.

For `D2`:

```text
D01 — content gap confirmation: what cannot be written well from internal sources
D02 — external source discovery: find likely sources for this gap
D03 — source unfolding: open/read selected sources and extract usable distinctions
D04 — integration decision: integrate now / source register only / future debt / reject
```

For `D3`, add:

```text
D05 — second-hop decision: follow only sources that directly answer the chapter gap
D06 — second-hop unfolding and integration decision
```

These module records become real pass records only for chapters that need them. They are not placeholders in every plan.

## 8. Optional source-restoration module

For `D1`, add a small module only if primary-source restoration is materially needed:

```text
R01 — restore primary sources for claims/images already known from Atlas/dossiers
R02 — update source_register and unresolved source debts
```

If no restoration is needed, do not add the module.

## 9. Guardrails for chapter writing

### 9.1. No method catalog

Do not write:

```text
SPDD делает..., Spec Kit делает..., Kiro делает..., ADR делает...
```

Write around the chapter’s lifecycle transition. Methods appear as evidence, contrast and boundary cases.

### 9.2. Atlas is baseline, not a source dump

Use Atlas articles for concepts, boundaries, examples and technical anchors. Do not recap whole atlas articles.

### 9.3. Dossier is gap-check, not first draft

Dossiers restore details and missing distinctions. They do not replace the skeleton, fragments or Atlas as the organizing source.

### 9.4. External discovery must not expand scope silently

New sources are allowed to add real content, but each branch receives an integration decision. If it opens a new large topic, it becomes a future debt or separate appendix, not a stealth expansion of the current chapter.

### 9.5. Keep theory separate from Handbook/Fieldbook

Operational recipes, step-by-step tool instructions and package execution rituals are routed out. The chapter keeps conceptual distinctions, lifecycle transitions, evidence and boundaries.

## 10. Language and style

Use ordinary accepted rules:

- `russian-language.md` for language mode;
- `language-style-rules.md` and `human-technical-style.md` for final prose;
- language passes before repair/editorial;
- final style tail from the accepted Atlas process.

Do not create chapter-specific style rules unless the user explicitly asks. The priority is natural Russian technical prose, not proof that the protocol was executed.

## 11. Final regression check

Final checks:

- chapter exists and matches contract;
- no method catalog;
- no Atlas recap;
- no uncontrolled dossier/source dump;
- fragment salvage decisions recorded;
- Atlas concepts not distorted;
- important dossier gaps processed;
- external discovery module only appears if needed;
- source/provenance adequate for public claims;
- story anchors sparse and factual;
- visual candidates classified, no broken image refs;
- language/style tail completed;
- text reads naturally in Russian;
- companion files synchronized;
- discourse/map update instructions produced.
